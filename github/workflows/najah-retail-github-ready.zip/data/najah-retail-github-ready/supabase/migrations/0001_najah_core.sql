create extension if not exists pgcrypto;

create table if not exists public.tenants (
  id uuid primary key default gen_random_uuid(),
  shop_name text not null,
  owner_name text not null,
  activity_key text not null,
  country text not null,
  currency_code text not null,
  phone text,
  address text,
  tax_no text,
  license_status text not null default 'pending' check (license_status in ('active','expired','suspended','pending')),
  created_at timestamptz not null default now()
);

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete restrict,
  plan_code text not null,
  activity_key text not null,
  status text not null check (status in ('active','expired','suspended','pending')),
  started_at timestamptz not null,
  ends_at timestamptz not null,
  created_at timestamptz not null default now()
);

create table if not exists public.branches (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  name text not null,
  phone text,
  address text,
  created_at timestamptz not null default now()
);

create table if not exists public.user_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  branch_id uuid references public.branches(id),
  role_code text not null check (role_code in ('owner','manager','accountant','storekeeper','cashier','employee')),
  username text,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  branch_id uuid not null references public.branches(id) on delete restrict,
  activity_key text not null,
  name text not null,
  sku text not null,
  barcode text,
  purchase_price numeric(14,2) not null default 0,
  sale_price numeric(14,2) not null default 0,
  stock_qty numeric(14,3) not null default 0,
  reserved_qty numeric(14,3) not null default 0,
  min_stock numeric(14,3) not null default 0,
  activity_data jsonb not null default '{}'::jsonb,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  unique (tenant_id, sku),
  unique nulls not distinct (tenant_id, barcode)
);

create table if not exists public.suppliers (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  name text not null,
  phone text,
  address text,
  created_at timestamptz not null default now()
);

create table if not exists public.sales_invoices (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  invoice_no text not null,
  idempotency_key text not null,
  payment_method text not null,
  subtotal numeric(14,2) not null default 0,
  grand_total numeric(14,2) not null default 0,
  paid_amount numeric(14,2) not null default 0,
  remaining_amount numeric(14,2) not null default 0,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique (tenant_id, invoice_no),
  unique (tenant_id, idempotency_key)
);

create table if not exists public.sales_invoice_lines (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  invoice_id uuid not null references public.sales_invoices(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  qty numeric(14,3) not null,
  sale_price numeric(14,2) not null,
  cost_price numeric(14,2) not null,
  line_total numeric(14,2) not null
);

create table if not exists public.purchase_invoices (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  invoice_no text not null,
  supplier_id uuid not null references public.suppliers(id),
  subtotal numeric(14,2) not null default 0,
  extra_expenses numeric(14,2) not null default 0,
  discount_amount numeric(14,2) not null default 0,
  grand_total numeric(14,2) not null default 0,
  paid_amount numeric(14,2) not null default 0,
  remaining_amount numeric(14,2) not null default 0,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique (tenant_id, invoice_no)
);

create table if not exists public.purchase_invoice_lines (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  invoice_id uuid not null references public.purchase_invoices(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  qty numeric(14,3) not null,
  unit_cost numeric(14,2) not null,
  line_total numeric(14,2) not null
);

create table if not exists public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  branch_id uuid not null references public.branches(id),
  product_id uuid not null references public.products(id) on delete restrict,
  qty_delta numeric(14,3) not null,
  reason text not null,
  reference_type text not null,
  reference_id uuid,
  actor_id uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  branch_id uuid references public.branches(id),
  actor_id uuid references auth.users(id),
  action text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.is_tenant_member(target_tenant uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.user_profiles up
    where up.id = auth.uid()
      and up.tenant_id = target_tenant
  );
$$;

create or replace function public.current_branch_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select up.branch_id
  from public.user_profiles up
  where up.id = auth.uid()
  limit 1
$$;

alter table public.tenants enable row level security;
alter table public.licenses enable row level security;
alter table public.branches enable row level security;
alter table public.user_profiles enable row level security;
alter table public.products enable row level security;
alter table public.suppliers enable row level security;
alter table public.sales_invoices enable row level security;
alter table public.sales_invoice_lines enable row level security;
alter table public.purchase_invoices enable row level security;
alter table public.purchase_invoice_lines enable row level security;
alter table public.stock_movements enable row level security;
alter table public.audit_logs enable row level security;

drop policy if exists tenant_select_tenants on public.tenants;
create policy tenant_select_tenants on public.tenants
for select using (public.is_tenant_member(id));

drop policy if exists tenant_select_licenses on public.licenses;
create policy tenant_select_licenses on public.licenses
for select using (public.is_tenant_member(tenant_id));

drop policy if exists tenant_select_branches on public.branches;
create policy tenant_select_branches on public.branches
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

drop policy if exists tenant_select_profiles on public.user_profiles;
create policy tenant_select_profiles on public.user_profiles
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

drop policy if exists tenant_select_products on public.products;
create policy tenant_select_products on public.products
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

drop policy if exists tenant_select_suppliers on public.suppliers;
create policy tenant_select_suppliers on public.suppliers
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

drop policy if exists tenant_select_sales on public.sales_invoices;
create policy tenant_select_sales on public.sales_invoices
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

drop policy if exists tenant_select_sales_lines on public.sales_invoice_lines;
create policy tenant_select_sales_lines on public.sales_invoice_lines
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

drop policy if exists tenant_select_purchases on public.purchase_invoices;
create policy tenant_select_purchases on public.purchase_invoices
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

drop policy if exists tenant_select_purchase_lines on public.purchase_invoice_lines;
create policy tenant_select_purchase_lines on public.purchase_invoice_lines
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

drop policy if exists tenant_select_stock on public.stock_movements;
create policy tenant_select_stock on public.stock_movements
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

drop policy if exists tenant_select_audit on public.audit_logs;
create policy tenant_select_audit on public.audit_logs
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

create or replace function public.process_sale(
  p_tenant_id uuid,
  p_branch_id uuid,
  p_idempotency_key text,
  p_invoice_no text,
  p_payment_method text,
  p_paid_amount numeric,
  p_items jsonb,
  p_actor_id uuid
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_invoice_id uuid;
  v_subtotal numeric(14,2) := 0;
  v_item jsonb;
  v_product record;
  v_line_total numeric(14,2);
begin
  if exists (
    select 1 from public.sales_invoices
    where tenant_id = p_tenant_id and idempotency_key = p_idempotency_key
  ) then
    return (
      select id from public.sales_invoices
      where tenant_id = p_tenant_id and idempotency_key = p_idempotency_key
      limit 1
    );
  end if;

  insert into public.sales_invoices (
    tenant_id, branch_id, invoice_no, idempotency_key, payment_method,
    subtotal, grand_total, paid_amount, remaining_amount, created_by
  ) values (
    p_tenant_id, p_branch_id, p_invoice_no, p_idempotency_key, p_payment_method,
    0, 0, p_paid_amount, 0, p_actor_id
  ) returning id into v_invoice_id;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product
    from public.products
    where id = (v_item ->> 'product_id')::uuid
      and tenant_id = p_tenant_id
    for update;

    if not found then
      raise exception 'product_not_found';
    end if;

    if v_product.stock_qty < (v_item ->> 'qty')::numeric then
      raise exception 'negative_stock_blocked';
    end if;

    v_line_total := ((v_item ->> 'qty')::numeric * (v_item ->> 'sale_price')::numeric);
    v_subtotal := v_subtotal + v_line_total;

    insert into public.sales_invoice_lines (
      tenant_id, invoice_id, product_id, qty, sale_price, cost_price, line_total
    ) values (
      p_tenant_id,
      v_invoice_id,
      v_product.id,
      (v_item ->> 'qty')::numeric,
      (v_item ->> 'sale_price')::numeric,
      v_product.purchase_price,
      v_line_total
    );

    update public.products
      set stock_qty = stock_qty - (v_item ->> 'qty')::numeric
    where id = v_product.id;

    insert into public.stock_movements (
      tenant_id, branch_id, product_id, qty_delta, reason, reference_type, reference_id, actor_id
    ) values (
      p_tenant_id, p_branch_id, v_product.id, -((v_item ->> 'qty')::numeric), 'sale', 'sale', v_invoice_id, p_actor_id
    );
  end loop;

  update public.sales_invoices
  set subtotal = v_subtotal,
      grand_total = v_subtotal,
      remaining_amount = greatest(v_subtotal - p_paid_amount, 0)
  where id = v_invoice_id;

  insert into public.audit_logs (tenant_id, branch_id, actor_id, action, details)
  values (p_tenant_id, p_branch_id, p_actor_id, 'process_sale', jsonb_build_object('invoice_id', v_invoice_id, 'idempotency_key', p_idempotency_key));

  return v_invoice_id;
end;
$$;
