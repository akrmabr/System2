alter table public.tenants
  add column if not exists invoice_header_logo text;
