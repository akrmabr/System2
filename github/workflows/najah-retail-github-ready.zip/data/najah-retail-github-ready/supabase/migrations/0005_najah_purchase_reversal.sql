alter table public.purchase_invoices
  add column if not exists status text not null default 'posted' check (status in ('posted','returned','voided'));

create or replace function public.reverse_purchase_invoice(
  p_tenant_id uuid,
  p_invoice_id uuid,
  p_actor_id uuid,
  p_mode text default 'returned'
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_invoice record;
  v_line record;
begin
  select * into v_invoice
  from public.purchase_invoices
  where id = p_invoice_id
    and tenant_id = p_tenant_id
  for update;

  if not found then
    raise exception 'purchase_invoice_not_found';
  end if;

  if v_invoice.status <> 'posted' then
    raise exception 'purchase_invoice_already_reversed';
  end if;

  if p_mode not in ('returned', 'voided') then
    raise exception 'invalid_reverse_mode';
  end if;

  for v_line in
    select * from public.purchase_invoice_lines
    where invoice_id = p_invoice_id
      and tenant_id = p_tenant_id
  loop
    update public.products
      set stock_qty = greatest(stock_qty - v_line.qty, 0)
    where id = v_line.product_id;

    insert into public.stock_movements (
      tenant_id, branch_id, product_id, qty_delta, reason, reference_type, reference_id, actor_id
    ) values (
      p_tenant_id,
      v_invoice.branch_id,
      v_line.product_id,
      -(v_line.qty),
      p_mode,
      'purchase_' || p_mode,
      p_invoice_id,
      p_actor_id
    );
  end loop;

  update public.purchase_invoices
  set status = p_mode,
      remaining_amount = 0
  where id = p_invoice_id;

  insert into public.audit_logs (
    tenant_id, branch_id, actor_id, action, details
  ) values (
    p_tenant_id,
    v_invoice.branch_id,
    p_actor_id,
    'reverse_purchase_invoice',
    jsonb_build_object('invoice_id', p_invoice_id, 'mode', p_mode)
  );

  return true;
end;
$$;
