alter table public.user_profiles
  add column if not exists permissions jsonb not null default '{}'::jsonb,
  add column if not exists is_active boolean not null default true;

create table if not exists public.user_branch_access (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.user_profiles(id) on delete cascade,
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  branch_id uuid not null references public.branches(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (profile_id, branch_id)
);

create table if not exists public.platform_admins (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.platform_admin_logs (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references public.platform_admins(id) on delete set null,
  action text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.user_branch_access enable row level security;
alter table public.platform_admins enable row level security;
alter table public.platform_admin_logs enable row level security;

drop policy if exists tenant_select_user_branch_access on public.user_branch_access;
create policy tenant_select_user_branch_access on public.user_branch_access
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

create or replace function public.is_platform_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.platform_admins pa where pa.id = auth.uid()
  );
$$;

drop policy if exists platform_admins_self_select on public.platform_admins;
create policy platform_admins_self_select on public.platform_admins
for select using (id = auth.uid());

drop policy if exists platform_admin_logs_admin_select on public.platform_admin_logs;
create policy platform_admin_logs_admin_select on public.platform_admin_logs
for select using (public.is_platform_admin());
