create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  name text not null,
  phone text,
  email text,
  address text,
  opening_balance numeric(14,2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.customer_payments (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  customer_id uuid not null references public.customers(id) on delete cascade,
  amount numeric(14,2) not null,
  payment_method text not null default 'cash',
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

alter table public.sales_invoices
  add column if not exists customer_id uuid references public.customers(id) on delete set null,
  add column if not exists notes text;

alter table public.purchase_invoices
  add column if not exists notes text;

alter table public.customers enable row level security;
alter table public.customer_payments enable row level security;

drop policy if exists tenant_select_customers on public.customers;
create policy tenant_select_customers on public.customers
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

drop policy if exists tenant_select_customer_payments on public.customer_payments;
create policy tenant_select_customer_payments on public.customer_payments
for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

create or replace function public.process_sale(
  p_tenant_id uuid,
  p_branch_id uuid,
  p_idempotency_key text,
  p_invoice_no text,
  p_payment_method text,
  p_paid_amount numeric,
  p_items jsonb,
  p_actor_id uuid,
  p_customer_id uuid default null,
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_invoice_id uuid;
  v_subtotal numeric(14,2) := 0;
  v_item jsonb;
  v_product record;
  v_line_total numeric(14,2);
begin
  if exists (
    select 1 from public.sales_invoices
    where tenant_id = p_tenant_id and idempotency_key = p_idempotency_key
  ) then
    return (
      select id from public.sales_invoices
      where tenant_id = p_tenant_id and idempotency_key = p_idempotency_key
      limit 1
    );
  end if;

  insert into public.sales_invoices (
    tenant_id, branch_id, invoice_no, idempotency_key, payment_method,
    subtotal, grand_total, paid_amount, remaining_amount, created_by, customer_id, notes
  ) values (
    p_tenant_id, p_branch_id, p_invoice_no, p_idempotency_key, p_payment_method,
    0, 0, p_paid_amount, 0, p_actor_id, p_customer_id, p_notes
  ) returning id into v_invoice_id;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    select * into v_product
    from public.products
    where id = (v_item ->> 'product_id')::uuid
      and tenant_id = p_tenant_id
    for update;

    if not found then
      raise exception 'product_not_found';
    end if;

    if v_product.stock_qty < (v_item ->> 'qty')::numeric then
      raise exception 'negative_stock_blocked';
    end if;

    v_line_total := ((v_item ->> 'qty')::numeric * (v_item ->> 'sale_price')::numeric);
    v_subtotal := v_subtotal + v_line_total;

    insert into public.sales_invoice_lines (
      tenant_id, invoice_id, product_id, qty, sale_price, cost_price, line_total
    ) values (
      p_tenant_id,
      v_invoice_id,
      v_product.id,
      (v_item ->> 'qty')::numeric,
      (v_item ->> 'sale_price')::numeric,
      v_product.purchase_price,
      v_line_total
    );

    update public.products
      set stock_qty = stock_qty - (v_item ->> 'qty')::numeric
    where id = v_product.id;

    insert into public.stock_movements (
      tenant_id, branch_id, product_id, qty_delta, reason, reference_type, reference_id, actor_id
    ) values (
      p_tenant_id, p_branch_id, v_product.id, -((v_item ->> 'qty')::numeric), 'sale', 'sale', v_invoice_id, p_actor_id
    );
  end loop;

  update public.sales_invoices
  set subtotal = v_subtotal,
      grand_total = v_subtotal,
      remaining_amount = greatest(v_subtotal - p_paid_amount, 0)
  where id = v_invoice_id;

  insert into public.audit_logs (tenant_id, branch_id, actor_id, action, details)
  values (p_tenant_id, p_branch_id, p_actor_id, 'process_sale', jsonb_build_object('invoice_id', v_invoice_id, 'idempotency_key', p_idempotency_key, 'customer_id', p_customer_id));

  return v_invoice_id;
end;
$$;
