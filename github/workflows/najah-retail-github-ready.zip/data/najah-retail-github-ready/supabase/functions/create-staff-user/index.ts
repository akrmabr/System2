import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace('Bearer ', '').trim();
    const body = await req.json();
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { global: { headers: { Authorization: authHeader } } });

    const { data: authUser, error: authError } = await admin.auth.getUser(token);
    if (authError || !authUser.user) return Response.json({ ok: false, message: 'unauthorized' }, { status: 401, headers: corsHeaders });

    const { data: actor, error: actorError } = await admin.from('user_profiles').select('*').eq('id', authUser.user.id).single();
    if (actorError) throw actorError;
    const canManage = actor.role_code === 'owner' || actor.permissions?.manage_users === true;
    if (!canManage) return Response.json({ ok: false, message: 'missing_manage_users_permission' }, { status: 403, headers: corsHeaders });

    const email = body.email?.trim()?.toLowerCase();
    if (!email || !body.password) return Response.json({ ok: false, message: 'email_and_password_required' }, { status: 400, headers: corsHeaders });

    const { data: createdAuth, error: createAuthError } = await admin.auth.admin.createUser({
      email,
      password: body.password,
      email_confirm: true,
      user_metadata: { display_name: body.displayName || body.username || email },
    });
    if (createAuthError) throw createAuthError;

    const branchIds = Array.isArray(body.branchIds) && body.branchIds.length ? body.branchIds : [actor.branch_id];
    const { data: profile, error: profileError } = await admin.from('user_profiles').insert({
      id: createdAuth.user.id,
      tenant_id: actor.tenant_id,
      branch_id: branchIds[0],
      role_code: body.roleCode,
      username: body.username || email,
      display_name: body.displayName || body.username || email,
      permissions: body.permissions || {},
      is_active: true,
    }).select('*').single();
    if (profileError) throw profileError;

    const rows = branchIds.map((branchId) => ({ profile_id: profile.id, tenant_id: actor.tenant_id, branch_id: branchId }));
    const { error: accessError } = await admin.from('user_branch_access').insert(rows);
    if (accessError) throw accessError;

    await admin.from('audit_logs').insert({
      tenant_id: actor.tenant_id,
      branch_id: actor.branch_id,
      actor_id: actor.id,
      action: 'create_staff_user',
      details: { created_user_id: profile.id, role_code: body.roleCode, branches: branchIds },
    });

    return Response.json({ ok: true, profile }, { headers: corsHeaders });
  } catch (error) {
    return Response.json({ ok: false, message: error.message }, { status: 500, headers: corsHeaders });
  }
});
