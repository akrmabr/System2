import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace('Bearer ', '').trim();
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { global: { headers: { Authorization: authHeader } } });

    const { data: authUser, error: authError } = await admin.auth.getUser(token);
    if (authError || !authUser.user) return Response.json({ ok: false, message: 'unauthorized' }, { status: 401, headers: corsHeaders });

    const { data: platformAdmin, error: adminError } = await admin.from('platform_admins').select('*').eq('id', authUser.user.id).maybeSingle();
    if (adminError) throw adminError;
    if (!platformAdmin) return Response.json({ ok: false, message: 'not_platform_admin' }, { status: 403, headers: corsHeaders });

    const [tenantsRes, branchesRes, licensesRes, logsRes] = await Promise.all([
      admin.from('tenants').select('*').order('created_at', { ascending: false }),
      admin.from('branches').select('tenant_id,id'),
      admin.from('licenses').select('*').order('created_at', { ascending: false }),
      admin.from('platform_admin_logs').select('*').order('created_at', { ascending: false }).limit(50),
    ]);
    for (const r of [tenantsRes, branchesRes, licensesRes, logsRes]) if (r.error) throw r.error;

    const branchesByTenant: Record<string, number> = {};
    for (const branch of branchesRes.data || []) branchesByTenant[branch.tenant_id] = (branchesByTenant[branch.tenant_id] || 0) + 1;

    const latestLicenseByTenant: Record<string, any> = {};
    for (const lic of licensesRes.data || []) if (!latestLicenseByTenant[lic.tenant_id]) latestLicenseByTenant[lic.tenant_id] = lic;

    const tenants = (tenantsRes.data || []).map((tenant) => ({
      id: tenant.id,
      shopName: tenant.shop_name,
      ownerName: tenant.owner_name,
      activityKey: tenant.activity_key,
      phone: tenant.phone,
      country: tenant.country,
      licenseStatus: tenant.license_status,
      branchCount: branchesByTenant[tenant.id] || 0,
      license: latestLicenseByTenant[tenant.id] || null,
      createdAt: tenant.created_at,
    }));

    const stats = {
      totalTenants: tenants.length,
      activeTenants: tenants.filter((t) => t.licenseStatus === 'active').length,
      suspendedTenants: tenants.filter((t) => t.licenseStatus === 'suspended').length,
      totalBranches: Object.values(branchesByTenant).reduce((a, b) => a + b, 0),
    };

    return Response.json({ ok: true, admin: platformAdmin, tenants, stats, logs: logsRes.data || [] }, { headers: corsHeaders });
  } catch (error) {
    return Response.json({ ok: false, message: error.message }, { status: 500, headers: corsHeaders });
  }
});
