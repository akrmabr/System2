import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace('Bearer ', '').trim();
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { global: { headers: { Authorization: authHeader } } });

    const { data: userResult, error: userError } = await admin.auth.getUser(token);
    if (userError || !userResult.user) return Response.json({ ok: false, message: 'unauthorized' }, { status: 401, headers: corsHeaders });

    const userId = userResult.user.id;
    const { data: profile, error: profileError } = await admin.from('user_profiles').select('*').eq('id', userId).single();
    if (profileError) throw profileError;

    if (profile.is_active === false) return Response.json({ ok: false, message: 'inactive_user' }, { status: 403, headers: corsHeaders });

    const { data: tenant, error: tenantError } = await admin.from('tenants').select('*').eq('id', profile.tenant_id).single();
    if (tenantError) throw tenantError;

    const [branches, products, suppliers, sales, purchases, stockMovements, auditLogs, license, team, access, customers, customerPayments] = await Promise.all([
      admin.from('branches').select('*').eq('tenant_id', profile.tenant_id).order('created_at', { ascending: true }),
      admin.from('products').select('*').eq('tenant_id', profile.tenant_id).is('archived_at', null).order('created_at', { ascending: false }),
      admin.from('suppliers').select('*').eq('tenant_id', profile.tenant_id).order('created_at', { ascending: false }),
      admin.from('sales_invoices').select('*, sales_invoice_lines(*)').eq('tenant_id', profile.tenant_id).order('created_at', { ascending: false }),
      admin.from('purchase_invoices').select('*, purchase_invoice_lines(*)').eq('tenant_id', profile.tenant_id).order('created_at', { ascending: false }),
      admin.from('stock_movements').select('*').eq('tenant_id', profile.tenant_id).order('created_at', { ascending: false }).limit(200),
      admin.from('audit_logs').select('*').eq('tenant_id', profile.tenant_id).order('created_at', { ascending: false }).limit(200),
      admin.from('licenses').select('*').eq('tenant_id', profile.tenant_id).order('created_at', { ascending: false }).limit(1).maybeSingle(),
      admin.from('user_profiles').select('*').eq('tenant_id', profile.tenant_id).order('created_at', { ascending: false }),
      admin.from('user_branch_access').select('*').eq('tenant_id', profile.tenant_id),
      admin.from('customers').select('*').eq('tenant_id', profile.tenant_id).order('created_at', { ascending: false }),
      admin.from('customer_payments').select('*').eq('tenant_id', profile.tenant_id).order('created_at', { ascending: false }).limit(200),
    ]);

    for (const result of [branches, products, suppliers, sales, purchases, stockMovements, auditLogs, license, team, access, customers, customerPayments]) if (result.error) throw result.error;

    return Response.json({
      ok: true,
      session: {
        user: { id: userId, email: userResult.user.email, role: profile.role_code, username: profile.username, displayName: profile.display_name, permissions: profile.permissions || {} },
        tenant,
        branchId: profile.branch_id,
        branches: branches.data,
        products: products.data,
        suppliers: suppliers.data,
        sales: sales.data,
        purchases: purchases.data,
        stockMovements: stockMovements.data,
        auditLogs: auditLogs.data,
        license: license.data,
        team: team.data,
        access: access.data,
        customers: customers.data,
        customerPayments: customerPayments.data,
      },
    }, { headers: corsHeaders });
  } catch (error) {
    return Response.json({ ok: false, message: error.message }, { status: 500, headers: corsHeaders });
  }
});
