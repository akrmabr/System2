import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace('Bearer ', '').trim();
    const payload = await req.json();
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { global: { headers: { Authorization: authHeader } } });

    const { data: authUser, error: authError } = await admin.auth.getUser(token);
    if (authError || !authUser.user) return Response.json({ ok: false, message: 'unauthorized' }, { status: 401, headers: corsHeaders });

    const { data: actor, error: actorError } = await admin.from('user_profiles').select('*').eq('id', authUser.user.id).single();
    if (actorError) throw actorError;
    const canReverse = actor.role_code === 'owner' || actor.permissions?.void_invoices === true;
    if (!canReverse) return Response.json({ ok: false, message: 'missing_void_invoices_permission' }, { status: 403, headers: corsHeaders });

    const { data, error } = await admin.rpc('reverse_sale_invoice', {
      p_tenant_id: actor.tenant_id,
      p_invoice_id: payload.invoiceId,
      p_actor_id: actor.id,
      p_mode: payload.mode || 'returned',
    });
    if (error) throw error;

    return Response.json({ ok: true, reversed: data }, { headers: corsHeaders });
  } catch (error) {
    return Response.json({ ok: false, message: error.message }, { status: 500, headers: corsHeaders });
  }
});
