import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

const ownerPermissions = {
  manage_users: true,
  manage_branches: true,
  view_reports: true,
  view_profit: true,
  manage_sales: true,
  manage_purchases: true,
  manage_stock: true,
  edit_prices: true,
  void_invoices: true,
};

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const body = await req.json();
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

    const email = body.email?.trim()?.toLowerCase();
    if (!email || !body.password) return Response.json({ ok: false, message: 'email_and_password_required' }, { status: 400, headers: corsHeaders });

    const { data: authUser, error: authError } = await admin.auth.admin.createUser({
      email,
      password: body.password,
      email_confirm: true,
      user_metadata: { display_name: body.ownerName, username: body.username || email },
    });
    if (authError) throw authError;

    const { data: tenant, error: tenantError } = await admin.from('tenants').insert({
      shop_name: body.shopName,
      owner_name: body.ownerName,
      activity_key: body.activityKey,
      country: body.country,
      currency_code: body.currency,
      phone: body.phone,
      address: body.address,
      tax_no: body.taxNo,
      license_status: 'active',
    }).select('id').single();
    if (tenantError) throw tenantError;

    const { data: branch, error: branchError } = await admin.from('branches').insert({
      tenant_id: tenant.id,
      name: body.branchName,
      phone: body.phone,
      address: body.address,
    }).select('id').single();
    if (branchError) throw branchError;

    const { error: profileError } = await admin.from('user_profiles').insert({
      id: authUser.user.id,
      tenant_id: tenant.id,
      branch_id: branch.id,
      role_code: 'owner',
      username: body.username || email,
      display_name: body.ownerName,
      permissions: ownerPermissions,
      is_active: true,
    });
    if (profileError) throw profileError;

    const { error: accessError } = await admin.from('user_branch_access').insert({
      profile_id: authUser.user.id,
      tenant_id: tenant.id,
      branch_id: branch.id,
    });
    if (accessError) throw accessError;

    const { error: licenseError } = await admin.from('licenses').insert({
      tenant_id: tenant.id,
      plan_code: body.planCode || 'basic',
      activity_key: body.activityKey,
      status: 'active',
      started_at: new Date().toISOString(),
      ends_at: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString(),
    });
    if (licenseError) throw licenseError;

    await admin.from('audit_logs').insert({ tenant_id: tenant.id, branch_id: branch.id, actor_id: authUser.user.id, action: 'register_tenant', details: { source: 'edge_function' } });

    return Response.json({ ok: true, tenantId: tenant.id, userId: authUser.user.id, branchId: branch.id }, { headers: corsHeaders });
  } catch (error) {
    return Response.json({ ok: false, message: error.message }, { status: 500, headers: corsHeaders });
  }
});
