import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const payload = await req.json();
    const { data, error } = await supabase.rpc('process_sale', {
      p_tenant_id: payload.tenantId,
      p_branch_id: payload.branchId,
      p_idempotency_key: payload.idempotencyKey,
      p_invoice_no: payload.invoiceNo,
      p_payment_method: payload.paymentMethod,
      p_paid_amount: payload.paidAmount,
      p_items: payload.items,
      p_actor_id: payload.actorId,
      p_customer_id: payload.customerId || null,
      p_notes: payload.notes || null,
    });
    if (error) throw error;
    return Response.json({ ok: true, invoiceId: data }, { headers: corsHeaders });
  } catch (error) {
    return Response.json({ ok: false, message: error.message }, { status: 500, headers: corsHeaders });
  }
});
