import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace('Bearer ', '').trim();
    const body = await req.json();
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { global: { headers: { Authorization: authHeader } } });

    const { data: authUser, error: authError } = await admin.auth.getUser(token);
    if (authError || !authUser.user) return Response.json({ ok: false, message: 'unauthorized' }, { status: 401, headers: corsHeaders });

    const { data: actor, error: actorError } = await admin.from('user_profiles').select('*').eq('id', authUser.user.id).single();
    if (actorError) throw actorError;
    const canManage = actor.role_code === 'owner' || actor.permissions?.manage_branches === true;
    if (!canManage) return Response.json({ ok: false, message: 'missing_manage_branches_permission' }, { status: 403, headers: corsHeaders });

    const { data: branch, error: branchError } = await admin.from('branches').insert({
      tenant_id: actor.tenant_id,
      name: body.name,
      phone: body.phone || null,
      address: body.address || null,
    }).select('*').single();
    if (branchError) throw branchError;

    await admin.from('audit_logs').insert({
      tenant_id: actor.tenant_id,
      branch_id: branch.id,
      actor_id: actor.id,
      action: 'create_branch',
      details: { branch_name: branch.name },
    });

    return Response.json({ ok: true, branch }, { headers: corsHeaders });
  } catch (error) {
    return Response.json({ ok: false, message: error.message }, { status: 500, headers: corsHeaders });
  }
});
