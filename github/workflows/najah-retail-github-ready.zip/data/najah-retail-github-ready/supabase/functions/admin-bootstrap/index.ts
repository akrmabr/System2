import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const body = await req.json();
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { count, error: countError } = await admin.from('platform_admins').select('id', { count: 'exact', head: true });
    if (countError) throw countError;
    if ((count || 0) > 0) {
      return Response.json({ ok: false, message: 'platform_admin_already_exists' }, { status: 400, headers: corsHeaders });
    }

    const email = body.email?.trim()?.toLowerCase();
    if (!email || !body.password) {
      return Response.json({ ok: false, message: 'email_and_password_required' }, { status: 400, headers: corsHeaders });
    }

    const { data: createdUser, error: authError } = await admin.auth.admin.createUser({
      email,
      password: body.password,
      email_confirm: true,
      user_metadata: { display_name: body.displayName || 'Platform Admin' },
    });
    if (authError) throw authError;

    const { error: insertError } = await admin.from('platform_admins').insert({
      id: createdUser.user.id,
      email,
      display_name: body.displayName || 'Platform Admin',
    });
    if (insertError) throw insertError;

    await admin.from('platform_admin_logs').insert({
      admin_id: createdUser.user.id,
      action: 'bootstrap_admin',
      details: { email },
    });

    return Response.json({ ok: true, userId: createdUser.user.id }, { headers: corsHeaders });
  } catch (error) {
    return Response.json({ ok: false, message: error.message }, { status: 500, headers: corsHeaders });
  }
});
