import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace('Bearer ', '').trim();
    const body = await req.json();
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { global: { headers: { Authorization: authHeader } } });

    const { data: authUser, error: authError } = await admin.auth.getUser(token);
    if (authError || !authUser.user) return Response.json({ ok: false, message: 'unauthorized' }, { status: 401, headers: corsHeaders });

    const { data: platformAdmin, error: adminError } = await admin.from('platform_admins').select('*').eq('id', authUser.user.id).maybeSingle();
    if (adminError) throw adminError;
    if (!platformAdmin) return Response.json({ ok: false, message: 'not_platform_admin' }, { status: 403, headers: corsHeaders });

    const { data: latestLicense, error: latestError } = await admin.from('licenses').select('*').eq('tenant_id', body.tenantId).order('created_at', { ascending: false }).limit(1).single();
    if (latestError) throw latestError;

    const { error: tenantError } = await admin.from('tenants').update({ license_status: body.status }).eq('id', body.tenantId);
    if (tenantError) throw tenantError;

    const { error: insertError } = await admin.from('licenses').insert({
      tenant_id: body.tenantId,
      plan_code: body.planCode || latestLicense.plan_code,
      activity_key: latestLicense.activity_key,
      status: body.status,
      started_at: body.startedAt || latestLicense.started_at,
      ends_at: body.endsAt || latestLicense.ends_at,
    });
    if (insertError) throw insertError;

    await admin.from('platform_admin_logs').insert({
      admin_id: authUser.user.id,
      action: 'update_license',
      details: { tenantId: body.tenantId, status: body.status },
    });

    return Response.json({ ok: true }, { headers: corsHeaders });
  } catch (error) {
    return Response.json({ ok: false, message: error.message }, { status: 500, headers: corsHeaders });
  }
});
