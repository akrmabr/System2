const CONFIG = window.NAJAH_SUPABASE_CONFIG;
const app = document.getElementById('app');
const AUTH_STORAGE_KEY = 'najah_supabase_auth';

const BRAND = {
  projectName: 'سستم النجاح لإدارة المحال التجارية',
  projectNameEn: 'Al-Najah Retail System',
  supportPhone: '0121164581',
  whatsapp: '0969696787',
  invoiceLogo: new URL('assets/najah-logo.png', window.location.href).href,
};


const ACTIVITY_CATALOG = [
  { key: 'homeware', label: 'محلات الأواني المنزلية', icon: '🍽️', specializedFields: [['setType','نوع الطقم/القطعة'],['material','الخامة'],['size','المقاس'],['color','اللون'],['model','الموديل'],['wholesalePrice','سعر الجملة'],['retailPack','العبوة']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'furniture', label: 'محلات الأثاثات', icon: '🛋️', specializedFields: [['model','الموديل'],['size','المقاسات'],['color','الألوان'],['material','الخامة'],['customOrder','طلب خاص'],['downPayment','العربون'],['deliveryDate','موعد التسليم'],['assembly','تركيب وضمان']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'supermarket', label: 'السوبر ماركت والبقالات', icon: '🛒', specializedFields: [['barcode','الباركود'],['fastSell','بيع سريع'],['weightBased','يباع بالوزن'],['expiryDate','تاريخ الصلاحية'],['batchNo','رقم التشغيلة'],['unit','الوحدة'],['offerPrice','سعر العرض']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'phones', label: 'محلات الهواتف والإلكترونيات', icon: '📱', specializedFields: [['imei','IMEI'],['serialNo','الرقم التسلسلي'],['warrantyMonths','أشهر الضمان'],['deviceType','نوع الجهاز'],['buyerNotes','بيانات المشتري'],['maintenance','الصيانة']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'clothing', label: 'محلات الملابس', icon: '👕', specializedFields: [['sizes','المقاسات'],['colors','الألوان'],['model','الموديل'],['brand','الماركة'],['variants','المقاسات المتعددة'],['exchangePolicy','سياسة التبديل']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'cosmetics', label: 'محلات مستحضرات التجميل', icon: '💄', specializedFields: [['size','الحجم'],['brand','الماركة'],['batchNo','التشغيلة'],['expiryDate','الصلاحية'],['alertWindow','تنبيه انتهاء الصلاحية']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'building', label: 'محلات مواد البناء', icon: '🧱', specializedFields: [['unit','الوحدة'],['conversion','التحويل بين الوحدات'],['delivery','التوصيل'],['weight','الوزن/الطن'],['bags','الأكياس']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'appliances', label: 'محلات الأجهزة الكهربائية', icon: '🔌', specializedFields: [['model','الموديل'],['serialNo','الرقم التسلسلي'],['warrantyMonths','مدة الضمان'],['deviceType','نوع الجهاز']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'stationery', label: 'محلات المكتبات والأدوات المدرسية', icon: '📚', specializedFields: [['category','التصنيف'],['brand','الماركة'],['size','المقاس'],['unit','وحدة البيع'],['barcode','الباركود']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'perfume', label: 'محلات العطور', icon: '🧴', specializedFields: [['fragranceType','النوع'],['brand','الماركة'],['size','الحجم'],['concentration','التركيز'],['packaging','العبوة']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'shoes_bags', label: 'محلات الأحذية والحقائب', icon: '👟', specializedFields: [['model','الموديل'],['sizes','المقاسات'],['colors','الألوان'],['material','الخامة'],['brand','الماركة'],['barcode','الباركود']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'auto_parts', label: 'محلات قطع غيار السيارات', icon: '🚗', specializedFields: [['partNo','رقم القطعة'],['brand','الماركة'],['compatibleCars','الموديلات المتوافقة'],['manufacturer','الشركة المصنعة']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'sanitary', label: 'محلات الأدوات الصحية', icon: '🚿', specializedFields: [['toolType','نوع الأداة'],['size','المقاس'],['material','الخامة'],['brand','الماركة'],['packaging','العبوة']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'electrical_tools', label: 'محلات الأدوات الكهربائية', icon: '💡', specializedFields: [['category','الصنف'],['specs','المواصفات الفنية'],['size','المقاس'],['brand','الماركة'],['warrantyMonths','مدة الضمان']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
  { key: 'computers', label: 'محلات الحواسيب', icon: '💻', specializedFields: [['componentType','نوع الجهاز/المكوّن'],['specs','المواصفات الفنية'],['serialNo','الرقم التسلسلي'],['accessories','الملحقات'],['warrantyMonths','مدة الضمان']], sidebar: ['dashboard','products','sales','customers','purchases','inventory','reports','settings'] },
];

const PAYMENT_METHODS = [
  { value: 'cash', label: 'نقدي' },
  { value: 'electronic', label: 'إلكتروني' },
  { value: 'credit', label: 'آجل' },
];

const PERMISSIONS = [
  { key: 'manage_users', label: 'إدارة المستخدمين' },
  { key: 'manage_branches', label: 'إدارة الفروع' },
  { key: 'view_reports', label: 'عرض التقارير' },
  { key: 'view_profit', label: 'عرض الأرباح' },
  { key: 'manage_sales', label: 'إدارة المبيعات' },
  { key: 'manage_purchases', label: 'إدارة المشتريات' },
  { key: 'manage_stock', label: 'إدارة المخزون' },
  { key: 'edit_prices', label: 'تعديل الأسعار' },
  { key: 'void_invoices', label: 'إلغاء الفواتير والمرتجعات' },
];

const ROLE_TEMPLATES = {
  owner: Object.fromEntries(PERMISSIONS.map((p) => [p.key, true])),
  manager: { manage_users: true, manage_branches: true, view_reports: true, view_profit: true, manage_sales: true, manage_purchases: true, manage_stock: true, edit_prices: true, void_invoices: true },
  accountant: { manage_users: false, manage_branches: false, view_reports: true, view_profit: true, manage_sales: false, manage_purchases: true, manage_stock: false, edit_prices: false, void_invoices: false },
  storekeeper: { manage_users: false, manage_branches: false, view_reports: false, view_profit: false, manage_sales: false, manage_purchases: true, manage_stock: true, edit_prices: false, void_invoices: false },
  cashier: { manage_users: false, manage_branches: false, view_reports: false, view_profit: false, manage_sales: true, manage_purchases: false, manage_stock: false, edit_prices: false, void_invoices: false },
  employee: { manage_users: false, manage_branches: false, view_reports: false, view_profit: false, manage_sales: false, manage_purchases: false, manage_stock: false, edit_prices: false, void_invoices: false },
};

const state = {
  screen: 'loading',
  authTab: 'register',
  registrationActivity: ACTIVITY_CATALOG[0].key,
  session: null,
  adminData: null,
  adminExists: null,
  adminLoginMode: 'login',
  section: 'dashboard',
  cart: [],
  posSearch: '',
  invoicePrintSize: '80',
  syncing: false,
  notice: '',
  statusFeed: [],
  noticeKind: 'success',
};

const h = (strings, ...values) => strings.reduce((acc, str, i) => acc + str + (values[i] ?? ''), '');
const uid = (prefix = 'id') => `${prefix}_${crypto.randomUUID()}`;
const now = () => new Date().toISOString();
const formatDate = (v) => (v ? new Date(v).toLocaleString('ar-SA') : '-');
const currentTenant = () => state.session?.tenant || null;
const currentActivityConfig = () => ACTIVITY_CATALOG.find((a) => a.key === currentTenant()?.activityKey);
const invoiceHeaderLogo = () => currentTenant()?.invoiceHeaderLogo || BRAND.invoiceLogo;
const money = (value) => new Intl.NumberFormat('ar-SA', { style: 'currency', currency: currentTenant()?.currency || 'USD', maximumFractionDigits: 2 }).format(Number(value || 0));
const currentOperationalBranchId = () => state.selectedBranchId || state.session?.branchId || null;
const activeBranchName = () => state.session?.branches?.find((b) => b.id === currentOperationalBranchId())?.name || '-';
const currentUserPermissions = () => state.session?.user?.permissions || {};
const can = (permissionKey) => state.session?.user?.role === 'owner' || currentUserPermissions()[permissionKey] === true;
function availableBranchesForCurrentUser() {
  if (!state.session) return [];
  if (state.session.user.role === 'owner') return state.session.branches || [];
  const allowed = new Set((state.session.accessRows || []).filter((row) => row.profile_id === state.session.user.id).map((row) => row.branch_id));
  return (state.session.branches || []).filter((branch) => allowed.size ? allowed.has(branch.id) : branch.id === state.session.branchId);
}
function scopedItems(items, key = 'branchId') {
  const branchId = currentOperationalBranchId();
  if (!branchId) return items || [];
  return (items || []).filter((item) => !item[key] || item[key] === branchId);
}

function authState() {
  try { return JSON.parse(localStorage.getItem(AUTH_STORAGE_KEY) || 'null'); } catch { return null; }
}
function setAuthState(data) { localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(data)); }
function clearAuthState() { localStorage.removeItem(AUTH_STORAGE_KEY); }
function pushStatus(kind, text) {
  const message = String(text || '').trim();
  if (!message) return;
  state.notice = message;
  state.noticeKind = kind;
  state.statusFeed = [{ id: uid('status'), kind, text: message, at: now() }, ...state.statusFeed].slice(0, 8);
}
function setNotice(text) { pushStatus('success', text); }
function setErrorNotice(error) {
  const message = humanizeError(error);
  pushStatus('error', message);
  return message;
}
function validateConfig() {
  if (!CONFIG?.url || !CONFIG?.anonKey || !CONFIG?.functionsBase || !CONFIG?.projectRef) throw new Error('missing_config');
}
function humanizeError(error) {
  const message = String(error?.message || error || '');
  const map = {
    no_auth: 'انتهت الجلسة. سجّل الدخول مرة أخرى.',
    customer_required_for_credit: 'اختر أو أدخل عميلًا عند البيع الآجل.',
    unauthorized: 'ليس لديك صلاحية لتنفيذ هذا الإجراء.',
    not_platform_admin: 'هذا الحساب ليس حساب إدارة مركزية.',
    platform_admin_already_exists: 'تم إنشاء مدير المنصة بالفعل. استخدم تسجيل الدخول للإدارة.',
    email_and_password_required: 'يرجى إدخال البريد الإلكتروني وكلمة المرور.',
    missing_manage_branches_permission: 'ليس لديك صلاحية إدارة الفروع.',
    missing_manage_users_permission: 'ليس لديك صلاحية إدارة المستخدمين.',
    missing_manage_purchases_permission: 'ليس لديك صلاحية تنفيذ مرتجع المشتريات.',
    missing_void_invoices_permission: 'ليس لديك صلاحية إلغاء أو إرجاع الفواتير.',
    inactive_user: 'تم تعطيل هذا المستخدم. راجع مدير النظام.',
    missing_config: 'إعدادات الربط غير مكتملة. تأكد من ملف supabase.config.js.',
    negative_stock_blocked: 'الكمية المطلوبة غير متاحة في المخزون.',
    invoice_already_reversed: 'تمت معالجة هذه الفاتورة مسبقاً.',
    invoice_not_found: 'الفاتورة غير موجودة.',
    purchase_invoice_not_found: 'فاتورة الشراء غير موجودة.',
    purchase_invoice_already_reversed: 'تمت معالجة فاتورة الشراء مسبقاً.',
  };
  if (map[message]) return map[message];
  if (message.includes('fetch')) return 'تعذر الوصول إلى الخادم الآن. تحقق من الاتصال ثم أعد المحاولة.';
  if (message.startsWith('request_failed_')) return 'تعذر إكمال الطلب الآن. أعد المحاولة بعد لحظات.';
  return message || 'حدث خطأ غير متوقع. حاول مرة أخرى.';
}

async function apiFetch(url, options = {}) {
  validateConfig();
  const res = await fetch(url, options);
  const text = await res.text();
  let json = {};
  try { json = text ? JSON.parse(text) : {}; } catch { json = { raw: text }; }
  if (!res.ok || json.ok === false) throw new Error(json.message || json.error_description || json.error || `request_failed_${res.status}`);
  return json;
}

function headers(withAuth = false) {
  const hdr = { apikey: CONFIG.anonKey, 'Content-Type': 'application/json' };
  const auth = authState();
  if (withAuth && auth?.access_token) hdr.Authorization = `Bearer ${auth.access_token}`;
  return hdr;
}

async function callEdge(slug, payload = {}, withAuth = false) {
  return apiFetch(`${CONFIG.functionsBase}/${slug}`, {
    method: 'POST',
    headers: headers(withAuth),
    body: JSON.stringify(payload),
  });
}

async function restInsert(table, payload) {
  return apiFetch(`${CONFIG.url}/rest/v1/${table}`, {
    method: 'POST',
    headers: { ...headers(true), Prefer: 'return=representation' },
    body: JSON.stringify(payload),
  });
}

async function restUpdate(table, values, params) {
  return apiFetch(`${CONFIG.url}/rest/v1/${table}?${new URLSearchParams(params).toString()}`, {
    method: 'PATCH',
    headers: { ...headers(true), Prefer: 'return=representation' },
    body: JSON.stringify(values),
  });
}

async function authLogin(email, password) {
  const result = await apiFetch(`${CONFIG.url}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: headers(false),
    body: JSON.stringify({ email, password }),
  });
  setAuthState({ access_token: result.access_token, refresh_token: result.refresh_token, user: result.user });
  return result;
}

async function authLogout() {
  const auth = authState();
  if (auth?.access_token) {
    try {
      await fetch(`${CONFIG.url}/auth/v1/logout`, { method: 'POST', headers: { apikey: CONFIG.anonKey, Authorization: `Bearer ${auth.access_token}` } });
    } catch {}
  }
  clearAuthState();
}

function normalizeSession(payload) {
  const products = (payload.products || []).map((p) => ({
    id: p.id,
    name: p.name,
    code: p.sku,
    barcode: p.barcode || '',
    purchasePrice: Number(p.purchase_price || 0),
    salePrice: Number(p.sale_price || 0),
    stockQty: Number(p.stock_qty || 0),
    reservedQty: Number(p.reserved_qty || 0),
    minStock: Number(p.min_stock || 0),
    activityData: p.activity_data || {},
    branchId: p.branch_id,
    createdAt: p.created_at,
  }));
  const branchAccess = payload.access || [];
  return {
    user: {
      id: payload.user.id,
      email: payload.user.email,
      role: payload.user.role,
      username: payload.user.username,
      displayName: payload.user.displayName,
      permissions: payload.user.permissions || {},
    },
    tenant: {
      id: payload.tenant.id,
      shopName: payload.tenant.shop_name,
      ownerName: payload.tenant.owner_name,
      activityKey: payload.tenant.activity_key,
      country: payload.tenant.country,
      currency: payload.tenant.currency_code,
      phone: payload.tenant.phone,
      address: payload.tenant.address,
      taxNo: payload.tenant.tax_no,
      licenseStatus: payload.tenant.license_status,
      invoiceHeaderLogo: payload.tenant.invoice_header_logo || null,
    },
    branchId: payload.branchId,
    branches: (payload.branches || []).map((b) => ({ id: b.id, name: b.name, phone: b.phone, address: b.address })),
    products,
    suppliers: (payload.suppliers || []).map((s) => ({ id: s.id, name: s.name, phone: s.phone, address: s.address })),
    sales: (payload.sales || []).map((s) => ({
      id: s.id,
      invoiceNo: s.invoice_no,
      customerId: s.customer_id || null,
      notes: s.notes || '',
      paymentMethod: s.payment_method,
      status: s.status || 'posted',
      subtotal: Number(s.subtotal || 0),
      grandTotal: Number(s.grand_total || 0),
      paid: Number(s.paid_amount || 0),
      remaining: Number(s.remaining_amount || 0),
      branchId: s.branch_id,
      createdAt: s.created_at,
      items: (s.sales_invoice_lines || []).map((i) => ({
        id: i.id,
        productId: i.product_id,
        qty: Number(i.qty || 0),
        salePrice: Number(i.sale_price || 0),
        costPrice: Number(i.cost_price || 0),
        total: Number(i.line_total || 0),
        name: products.find((p) => p.id === i.product_id)?.name || 'صنف',
      })),
    })),
    purchases: (payload.purchases || []).map((p) => ({
      id: p.id,
      invoiceNo: p.invoice_no,
      supplierId: p.supplier_id,
      status: p.status || 'posted',
      notes: p.notes || '',
      subtotal: Number(p.subtotal || 0),
      extraExpenses: Number(p.extra_expenses || 0),
      discount: Number(p.discount_amount || 0),
      grandTotal: Number(p.grand_total || 0),
      paid: Number(p.paid_amount || 0),
      remaining: Number(p.remaining_amount || 0),
      branchId: p.branch_id,
      createdAt: p.created_at,
      items: (p.purchase_invoice_lines || []).map((i) => ({
        id: i.id,
        productId: i.product_id,
        qty: Number(i.qty || 0),
        unitCost: Number(i.unit_cost || 0),
        total: Number(i.line_total || 0),
        name: products.find((prd) => prd.id === i.product_id)?.name || 'صنف',
      })),
    })),
    stockMovements: (payload.stockMovements || []).map((m) => ({ id: m.id, productId: m.product_id, branchId: m.branch_id, qtyDelta: Number(m.qty_delta || 0), reason: m.reason, referenceType: m.reference_type, referenceId: m.reference_id, at: m.created_at, actor: m.actor_id || 'user' })),
    auditLogs: (payload.auditLogs || []).map((a) => ({ id: a.id, branchId: a.branch_id, action: a.action, details: typeof a.details === 'string' ? a.details : JSON.stringify(a.details || {}), at: a.created_at, actor: a.actor_id || 'user' })),
    license: payload.license ? { id: payload.license.id, status: payload.license.status, startedAt: payload.license.started_at, endsAt: payload.license.ends_at, activityKey: payload.license.activity_key, plan: payload.license.plan_code } : null,
    customers: (payload.customers || []).map((c) => ({ id: c.id, branchId: c.branch_id, name: c.name, phone: c.phone || '', email: c.email || '', address: c.address || '', openingBalance: Number(c.opening_balance || 0), createdAt: c.created_at })),
    customerPayments: (payload.customerPayments || []).map((c) => ({ id: c.id, branchId: c.branch_id, customerId: c.customer_id, amount: Number(c.amount || 0), paymentMethod: c.payment_method, notes: c.notes || '', createdAt: c.created_at })),
    accessRows: branchAccess,
    team: (payload.team || []).map((member) => ({
      id: member.id,
      roleCode: member.role_code,
      username: member.username,
      displayName: member.display_name,
      permissions: member.permissions || {},
      isActive: member.is_active,
      branches: branchAccess.filter((a) => a.profile_id === member.id).map((a) => a.branch_id),
    })),
  };
}

function normalizeAdmin(payload) {
  return {
    admin: payload.admin,
    stats: payload.stats,
    tenants: payload.tenants || [],
    logs: payload.logs || [],
  };
}

async function fetchAdminStatus() {
  try {
    const result = await callEdge('admin-status');
    state.adminExists = result.exists;
    state.adminLoginMode = result.exists ? 'login' : 'bootstrap';
  } catch {
    state.adminExists = false;
    state.adminLoginMode = 'bootstrap';
  }
}

async function bootstrapShopSession() {
  const auth = authState();
  if (!auth?.access_token) throw new Error('no_auth');
  const result = await callEdge('bootstrap-session', {}, true);
  state.session = normalizeSession(result.session);
  const branches = availableBranchesForCurrentUser();
  state.selectedBranchId = branches.find((branch) => branch.id === state.selectedBranchId)?.id || branches[0]?.id || state.session.branchId;
  state.adminData = null;
  state.screen = 'app';
}

async function bootstrapAdminSession() {
  const auth = authState();
  if (!auth?.access_token) throw new Error('no_auth');
  const result = await callEdge('admin-dashboard', {}, true);
  state.adminData = normalizeAdmin(result);
  state.session = null;
  state.screen = 'admin';
}

async function initializeSession() {
  await fetchAdminStatus();
  const auth = authState();
  if (!auth?.access_token) {
    state.screen = 'welcome';
    return;
  }
  try {
    await bootstrapShopSession();
    const license = await callEdge('verify-license', { tenantId: currentTenant().id });
    if (!license.active) {
      await authLogout();
      state.screen = 'welcome';
      throw new Error('الترخيص غير نشط حاليًا.');
    }
    return;
  } catch {}
  try {
    await bootstrapAdminSession();
    return;
  } catch {}
  await authLogout();
  state.screen = 'welcome';
}

async function registerTenant(form) {
  await callEdge('register-tenant', {
    shopName: form.shopName,
    ownerName: form.ownerName,
    activityKey: form.activityKey,
    country: form.country,
    currency: form.currency,
    phone: form.phone,
    address: form.address,
    taxNo: form.taxNo,
    branchName: form.branchName,
    username: form.username,
    email: form.email,
    password: form.password,
    planCode: 'basic',
  });
  await authLogin(form.email, form.password);
  await bootstrapShopSession();
  setNotice('تم إنشاء المحل وربطه بالنشاط والترخيص بنجاح.');
}

async function loginTenant(email, password) {
  await authLogin(email, password);
  await bootstrapShopSession();
  const license = await callEdge('verify-license', { tenantId: currentTenant().id });
  if (!license.active) {
    await authLogout();
    throw new Error('الترخيص غير نشط حاليًا.');
  }
  setNotice('تم تسجيل الدخول إلى نظام المحل.');
}

async function bootstrapAdmin(form) {
  await callEdge('admin-bootstrap', { email: form.email, password: form.password, displayName: form.displayName || 'Platform Admin' });
  await fetchAdminStatus();
  await authLogin(form.email, form.password);
  await bootstrapAdminSession();
  setNotice('تم إنشاء أول مدير للمنصة وفتح لوحة الإدارة المركزية.');
}

async function loginAdmin(email, password) {
  await authLogin(email, password);
  await bootstrapAdminSession();
  setNotice('تم تسجيل الدخول إلى لوحة الإدارة المركزية.');
}

async function logoutAll() {
  await authLogout();
  setNotice('تم تسجيل الخروج.');
  state.session = null;
  state.adminData = null;
  state.screen = 'welcome';
  state.cart = [];
  await fetchAdminStatus();
}

function buildPermissionMap(formData, roleCode) {
  const template = { ...(ROLE_TEMPLATES[roleCode] || ROLE_TEMPLATES.employee) };
  for (const permission of PERMISSIONS) {
    template[permission.key] = formData.get(permission.key) === 'on';
  }
  return template;
}

function activityPayloadFromForm(activity, form) {
  const data = {};
  activity.specializedFields.forEach(([key]) => { data[key] = form[key] || ''; });
  return data;
}

async function updateProductDetails(form) {
  const product = state.session.products.find((item) => item.id === form.productId);
  if (!product) throw new Error('اختر صنفًا صالحًا.');
  await restUpdate('products', {
    sale_price: Number(form.salePrice || product.salePrice || 0),
    purchase_price: Number(form.purchasePrice || product.purchasePrice || 0),
    min_stock: Number(form.minStock || product.minStock || 0),
  }, { id: `eq.${product.id}` });
  await restInsert('audit_logs', {
    tenant_id: currentTenant().id,
    branch_id: currentOperationalBranchId(),
    actor_id: state.session.user.id,
    action: 'update_product',
    details: { product_id: product.id },
  });
  await bootstrapShopSession();
  setNotice('تم تحديث بيانات الصنف.');
}

async function adjustStock(form) {
  const product = state.session.products.find((item) => item.id === form.productId);
  if (!product) throw new Error('اختر صنفًا صالحًا.');
  const qtyDelta = Number(form.qtyDelta || 0);
  if (!qtyDelta) throw new Error('أدخل كمية التعديل.');
  const nextQty = Number(product.stockQty || 0) + qtyDelta;
  if (nextQty < 0) throw new Error('لا يمكن أن يصبح المخزون بالسالب.');
  await restUpdate('products', { stock_qty: nextQty }, { id: `eq.${product.id}` });
  await restInsert('stock_movements', {
    tenant_id: currentTenant().id,
    branch_id: currentOperationalBranchId(),
    product_id: product.id,
    qty_delta: qtyDelta,
    reason: form.reason || 'manual_adjustment',
    reference_type: 'adjustment',
    reference_id: product.id,
    actor_id: state.session.user.id,
  });
  await restInsert('audit_logs', {
    tenant_id: currentTenant().id,
    branch_id: currentOperationalBranchId(),
    actor_id: state.session.user.id,
    action: 'adjust_stock',
    details: { product_id: product.id, qty_delta: qtyDelta, note: form.note || '' },
  });
  await bootstrapShopSession();
  setNotice('تمت تسوية المخزون بنجاح.');
}

async function createProduct(form) {
  const activity = currentActivityConfig();
  const tenant = currentTenant();
  const created = await restInsert('products', {
    tenant_id: tenant.id,
    branch_id: currentOperationalBranchId(),
    activity_key: tenant.activityKey,
    name: form.name,
    sku: form.code || uid('sku'),
    barcode: form.barcode || null,
    purchase_price: Number(form.purchasePrice || 0),
    sale_price: Number(form.salePrice || 0),
    stock_qty: Number(form.stockQty || 0),
    reserved_qty: 0,
    min_stock: Number(form.minStock || 0),
    activity_data: activityPayloadFromForm(activity, form),
  });
  if (Number(form.stockQty || 0) > 0) {
    await restInsert('stock_movements', {
      tenant_id: tenant.id,
      branch_id: currentOperationalBranchId(),
      product_id: created[0].id,
      qty_delta: Number(form.stockQty || 0),
      reason: 'opening_balance',
      reference_type: 'opening',
      reference_id: created[0].id,
      actor_id: state.session.user.id,
    });
  }
  await restInsert('audit_logs', {
    tenant_id: tenant.id,
    branch_id: currentOperationalBranchId(),
    actor_id: state.session.user.id,
    action: 'create_product',
    details: { product_id: created[0].id },
  });
  await bootstrapShopSession();
  setNotice('تم حفظ الصنف على الخادم.');
}

async function ensureSupplier(name, phone) {
  const existing = state.session.suppliers.find((s) => s.name === name.trim());
  if (existing) return existing;
  const created = await restInsert('suppliers', { tenant_id: currentTenant().id, name: name.trim(), phone: phone || null, address: null });
  return { id: created[0].id, name: created[0].name, phone: created[0].phone, address: created[0].address };
}

async function ensureCustomer(name, phone = '', email = '', address = '') {
  const cleanName = String(name || '').trim();
  if (!cleanName) return null;
  const existing = (state.session.customers || []).find((customer) => customer.name === cleanName && (phone ? customer.phone === phone : true));
  if (existing) return existing;
  const created = await restInsert('customers', {
    tenant_id: currentTenant().id,
    branch_id: currentOperationalBranchId(),
    name: cleanName,
    phone: phone || null,
    email: email || null,
    address: address || null,
  });
  return { id: created[0].id, branchId: created[0].branch_id, name: created[0].name, phone: created[0].phone || '', email: created[0].email || '', address: created[0].address || '', openingBalance: Number(created[0].opening_balance || 0), createdAt: created[0].created_at };
}

function customerOutstanding(customerId) {
  const invoices = (state.session.sales || []).filter((sale) => sale.customerId === customerId);
  const invoiceDue = invoices.reduce((sum, invoice) => sum + Number(invoice.remaining || 0), 0);
  const payments = (state.session.customerPayments || []).filter((payment) => payment.customerId === customerId).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  const customer = (state.session.customers || []).find((item) => item.id === customerId);
  return invoiceDue - payments + Number(customer?.openingBalance || 0);
}

async function createCustomer(form) {
  await ensureCustomer(form.name, form.phone, form.email, form.address);
  await restInsert('audit_logs', { tenant_id: currentTenant().id, branch_id: currentOperationalBranchId(), actor_id: state.session.user.id, action: 'create_customer', details: { name: form.name } });
  await bootstrapShopSession();
  setNotice('تم حفظ العميل.');
}

async function receiveCustomerPayment(form) {
  const customer = (state.session.customers || []).find((item) => item.id === form.customerId);
  if (!customer) throw new Error('اختر عميلًا صالحًا.');
  await restInsert('customer_payments', {
    tenant_id: currentTenant().id,
    branch_id: currentOperationalBranchId(),
    customer_id: customer.id,
    amount: Number(form.amount || 0),
    payment_method: form.paymentMethod || 'cash',
    notes: form.notes || null,
    created_by: state.session.user.id,
  });
  await restInsert('audit_logs', { tenant_id: currentTenant().id, branch_id: currentOperationalBranchId(), actor_id: state.session.user.id, action: 'customer_payment', details: { customer_id: customer.id, amount: Number(form.amount || 0) } });
  await bootstrapShopSession();
  setNotice('تم تسجيل دفعة العميل.');
}

async function recordPurchase(form) {
  const tenantId = currentTenant().id;
  const product = scopedItems(state.session.products).find((p) => p.id === form.productId);
  if (!product) throw new Error('اختر صنفًا صالحًا.');
  const supplier = await ensureSupplier(form.supplierName, form.supplierPhone);
  const qty = Number(form.qty || 0);
  const unitCost = Number(form.unitCost || product.purchasePrice || 0);
  const discount = Number(form.discount || 0);
  const extra = Number(form.extraExpenses || 0);
  const subtotal = qty * unitCost;
  const grandTotal = subtotal + extra - discount;
  const paid = Number(form.paid || 0);
  const purchase = await restInsert('purchase_invoices', {
    tenant_id: tenantId,
    branch_id: currentOperationalBranchId(),
    invoice_no: `PUR-${Date.now()}`,
    supplier_id: supplier.id,
    subtotal,
    extra_expenses: extra,
    discount_amount: discount,
    grand_total: grandTotal,
    paid_amount: paid,
    remaining_amount: grandTotal - paid,
    created_by: state.session.user.id,
  });
  await restInsert('purchase_invoice_lines', {
    tenant_id: tenantId,
    invoice_id: purchase[0].id,
    product_id: product.id,
    qty,
    unit_cost: unitCost,
    line_total: subtotal,
  });
  await restUpdate('products', { stock_qty: product.stockQty + qty, purchase_price: unitCost }, { id: `eq.${product.id}` });
  await restInsert('stock_movements', {
    tenant_id: tenantId,
    branch_id: currentOperationalBranchId(),
    product_id: product.id,
    qty_delta: qty,
    reason: 'purchase',
    reference_type: 'purchase',
    reference_id: purchase[0].id,
    actor_id: state.session.user.id,
  });
  await restInsert('audit_logs', {
    tenant_id: tenantId,
    branch_id: currentOperationalBranchId(),
    actor_id: state.session.user.id,
    action: 'create_purchase',
    details: { purchase_id: purchase[0].id },
  });
  await bootstrapShopSession();
  setNotice('تم تسجيل فاتورة الشراء وتحديث المخزون.');
}

function addToCart(productId) {
  const product = scopedItems(state.session.products).find((p) => p.id === productId);
  if (!product) return;
  const found = state.cart.find((i) => i.productId === productId);
  if (found) {
    if (found.qty + 1 > product.stockQty) return setErrorNotice('لا يمكن تجاوز الكمية المتاحة.');
    found.qty += 1;
  } else {
    if (product.stockQty < 1) return setErrorNotice('المخزون غير متاح.');
    state.cart.push({ productId, name: product.name, qty: 1, salePrice: product.salePrice, costPrice: product.purchasePrice });
  }
  render();
}

function updateCartQty(productId, qty) {
  const product = scopedItems(state.session.products).find((p) => p.id === productId);
  const item = state.cart.find((i) => i.productId === productId);
  const nextQty = Number(qty);
  if (!item || !product) return;
  if (nextQty < 1) state.cart = state.cart.filter((i) => i.productId !== productId);
  else if (nextQty > product.stockQty) setErrorNotice('الكمية تتجاوز المخزون المتاح.');
  else item.qty = nextQty;
  render();
}

function cartTotals() {
  const subtotal = state.cart.reduce((sum, item) => sum + Number(item.salePrice) * Number(item.qty), 0);
  return { subtotal, grandTotal: subtotal };
}

async function checkoutSale(form) {
  if (!state.cart.length) throw new Error('أضف منتجًا واحدًا على الأقل.');
  const customerName = String(form.customerName || '').trim();
  const customerPhone = String(form.customerPhone || '').trim();
  let customer = null;
  if (customerName) customer = await ensureCustomer(customerName, customerPhone);
  if (form.paymentMethod === 'credit' && !customer) throw new Error('customer_required_for_credit');
  const payload = {
    tenantId: currentTenant().id,
    branchId: currentOperationalBranchId(),
    idempotencyKey: form.idempotencyKey || uid('idem'),
    invoiceNo: `INV-${Date.now()}`,
    paymentMethod: form.paymentMethod,
    paidAmount: Number(form.paid || 0),
    actorId: state.session.user.id,
    customerId: customer?.id || null,
    notes: form.notes || null,
    items: state.cart.map((item) => ({ product_id: item.productId, qty: item.qty, sale_price: item.salePrice })),
  };
  const result = await callEdge('process-sale', payload, true);
  const cartSnapshot = state.cart.map((i) => ({ ...i }));
  await bootstrapShopSession();
  const totals = cartTotals();
  const sale = state.session.sales.find((s) => s.id === result.invoiceId) || { invoiceNo: payload.invoiceNo, grandTotal: totals.grandTotal, paid: payload.paidAmount, remaining: Math.max(totals.grandTotal - payload.paidAmount, 0), createdAt: now(), items: cartSnapshot };
  state.cart = [];
  printInvoice(sale, state.invoicePrintSize);
  setNotice('تمت عملية البيع وتحديث المخزون والطباعة.');
}

async function createBranch(form) {
  await callEdge('create-branch', form, true);
  await bootstrapShopSession();
  setNotice('تم إنشاء الفرع الجديد وربطه بالمحل.');
}

async function updateInvoiceHeaderLogo(formEl) {
  const file = formEl.querySelector('input[name="invoiceHeaderLogo"]')?.files?.[0];
  if (!file) throw new Error('اختر ملف شعار أولاً.');
  const dataUrl = await readFileAsDataUrl(file);
  await restUpdate('tenants', { invoice_header_logo: dataUrl }, { id: `eq.${currentTenant().id}` });
  await restInsert('audit_logs', {
    tenant_id: currentTenant().id,
    branch_id: currentOperationalBranchId(),
    actor_id: state.session.user.id,
    action: 'update_invoice_header_logo',
    details: { updated: true },
  });
  await bootstrapShopSession();
  setNotice('تم تحديث شعار رأس الفاتورة من الإعدادات.');
}

async function createStaffUser(formData) {
  const branchIds = formData.getAll('branchIds');
  if (!branchIds.length) throw new Error('اختر فرعًا واحدًا على الأقل.');
  const roleCode = formData.get('roleCode');
  await callEdge('create-staff-user', {
    email: formData.get('email'),
    password: formData.get('password'),
    username: formData.get('username'),
    displayName: formData.get('displayName'),
    roleCode,
    branchIds,
    permissions: buildPermissionMap(formData, roleCode),
  }, true);
  await bootstrapShopSession();
  setNotice('تم إنشاء المستخدم وربطه بالصلاحيات والفروع المحددة.');
}

async function toggleUserActive(profileId, nextActive) {
  if (profileId === state.session.user.id) throw new Error('لا يمكن تعديل حالة الحساب الحالي من هنا.');
  await restUpdate('user_profiles', { is_active: nextActive }, { id: `eq.${profileId}` });
  await restInsert('audit_logs', {
    tenant_id: currentTenant().id,
    branch_id: currentOperationalBranchId(),
    actor_id: state.session.user.id,
    action: nextActive ? 'activate_user' : 'deactivate_user',
    details: { profile_id: profileId },
  });
  await bootstrapShopSession();
  setNotice(nextActive ? 'تم تفعيل المستخدم.' : 'تم تعطيل المستخدم.');
}

async function updateLicense(tenantId, status) {
  await callEdge('admin-update-license', { tenantId, status }, true);
  await bootstrapAdminSession();
  setNotice('تم تحديث حالة الترخيص من لوحة الإدارة المركزية.');
}
async function reverseSale(invoiceId, mode = 'returned') {
  await callEdge('reverse-sale', { invoiceId, mode }, true);
  await bootstrapShopSession();
  setNotice(mode === 'voided' ? 'تم إلغاء الفاتورة وإرجاع المخزون.' : 'تم تسجيل مرتجع الفاتورة وإرجاع المخزون.');
}

async function reversePurchase(invoiceId, mode = 'returned') {
  await callEdge('reverse-purchase', { invoiceId, mode }, true);
  await bootstrapShopSession();
  setNotice(mode === 'voided' ? 'تم إلغاء فاتورة الشراء وتعديل المخزون.' : 'تم تسجيل مرتجع شراء وتعديل المخزون.');
}


function computeKpis() {
  const salesRows = scopedItems(state.session.sales).filter((row) => row.status === 'posted');
  const purchaseRows = scopedItems(state.session.purchases).filter((row) => row.status === 'posted');
  const products = scopedItems(state.session.products);
  const sales = salesRows.reduce((s, x) => s + x.grandTotal, 0);
  const purchases = purchaseRows.reduce((s, x) => s + x.grandTotal, 0);
  const stock = products.reduce((s, p) => s + p.stockQty, 0);
  const due = salesRows.reduce((s, x) => s + (x.remaining || 0), 0) + purchaseRows.reduce((s, x) => s + (x.remaining || 0), 0);
  return { sales, purchases, stock, due };
}

function calculateReports() {
  const salesRows = scopedItems(state.session.sales).filter((row) => row.status === 'posted');
  const products = scopedItems(state.session.products);
  const revenue = salesRows.reduce((s, inv) => s + inv.grandTotal, 0);
  const cogs = salesRows.reduce((sum, inv) => sum + inv.items.reduce((a, item) => a + Number(item.costPrice || 0) * Number(item.qty || 0), 0), 0);
  const expenses = 0;
  const profit = revenue - cogs - expenses;
  const stagnant = products.filter((p) => !salesRows.some((s) => s.items.some((i) => i.productId === p.id))).length;
  return { revenue, cogs, expenses, profit, stagnant };
}

function permissionSummary(map) {
  return PERMISSIONS.filter((p) => map?.[p.key]).map((p) => p.label).join('، ') || 'بدون صلاحيات إضافية';
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('تعذر قراءة ملف الشعار.'));
    reader.readAsDataURL(file);
  });
}

function downloadCsv(filename, headersRow, rows) {
  const escapeCell = (value) => {
    const text = String(value ?? '');
    return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };
  const csv = [headersRow, ...rows].map((row) => row.map(escapeCell).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function printInvoice(sale, size = '80') {
  const tenant = currentTenant();
  const w = window.open('', '_blank', 'width=900,height=700');
  const rows = (sale.items || []).map((item) => `<tr><td>${item.name || 'صنف'}</td><td>${item.qty}</td><td>${money(item.salePrice)}</td><td>${money(item.total || item.salePrice * item.qty)}</td></tr>`).join('');
  w.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${sale.invoiceNo}</title><style>
  body{font-family:Tahoma,Arial,sans-serif;padding:${size==='58' ? '8px':'16px'};width:${size==='58'?'58mm':size==='80'?'80mm':'210mm'};margin:auto;color:#0f172a}
  .print-sheet{position:relative;overflow:hidden;border:1px solid #e2e8f0;border-radius:16px;padding:${size==='58' ? '8px' : '18px'};background:#fff}
  .invoice-watermark{position:absolute;inset:12% 8%;background:url('${BRAND.invoiceLogo}') center center / ${size==='58' ? '78%' : size==='80' ? '68%' : '52%'} no-repeat;opacity:0.08;transform:rotate(-10deg);pointer-events:none;z-index:0}
  .invoice-content{position:relative;z-index:1}
  .invoice-head{text-align:center;border-bottom:1px solid #e2e8f0;padding-bottom:12px;margin-bottom:12px}
  .invoice-logo{max-width:${size==='58' ? '110px' : size==='80' ? '150px' : '220px'};max-height:${size==='58' ? '110px' : size==='80' ? '150px' : '220px'};object-fit:contain;margin:0 auto 8px;display:block}
  .brand-sub{font-size:${size==='58' ? '10px':'12px'};color:#475569}
  table{width:100%;border-collapse:collapse;margin-top:10px}
  td,th{padding:6px 0;border-bottom:1px dashed #cbd5e1;text-align:right;font-size:${size==='58' ? '11px':'13px'}}
  h1,h2,p{margin:0 0 8px}
  .invoice-meta,.invoice-totals,.invoice-support{margin-top:10px;font-size:${size==='58' ? '11px':'13px'}}
  .invoice-support{border-top:1px solid #e2e8f0;padding-top:10px;text-align:center;color:#0f172a}
  .support-line{color:#ea580c;font-weight:bold}
  </style></head><body><div class="print-sheet"><div class="invoice-watermark"></div><div class="invoice-content"><div class="invoice-head"><img src="${invoiceHeaderLogo()}" alt="${BRAND.projectName}" class="invoice-logo" /><h1>${tenant.shopName}</h1><p class="brand-sub">${BRAND.projectName}</p><p>${tenant.address || ''}</p><p>${tenant.phone || ''}</p><h2>فاتورة ${sale.invoiceNo}</h2><p>${formatDate(sale.createdAt)}</p></div><table><thead><tr><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>${rows}</tbody></table><div class="invoice-totals"><p><strong>الإجمالي:</strong> ${money(sale.grandTotal)}</p><p><strong>المدفوع:</strong> ${money(sale.paid)}</p><p><strong>المتبقي:</strong> ${money(sale.remaining)}</p></div><div class="invoice-support"><p><strong>الدعم والإعلان</strong></p><p class="support-line">رقم التواصل والدعم: ${BRAND.supportPhone}</p><p class="support-line">واتساب: ${BRAND.whatsapp}</p></div></div></div><script>window.onload=()=>window.print()</script></body></html>`);
  w.document.close();
}

function noticeBlock() {
  if (!state.notice) return '';
  return `<div class="flash ${state.noticeKind || 'success'}" style="margin-bottom:16px">${state.notice}</div>`;
}


function renderLoading() {
  app.innerHTML = `<div class="hero"><div class="panel"><h1 class="title">جاري تجهيز ${BRAND.projectName}…</h1><p class="subtitle">${state.syncing ? 'يتم تنفيذ العملية على Supabase الحقيقي.' : 'جاري التحقق من الجلسة والربط.'}</p></div></div>`;
}

function renderRegisterForm(selected) {
  return h`<form id="register-form" class="grid"><div class="field"><label>النشاط التجاري</label><select name="activityKey">${ACTIVITY_CATALOG.map((a) => `<option value="${a.key}" ${a.key===state.registrationActivity?'selected':''}>${a.label}</option>`).join('')}</select></div><div class="selection-chip">${selected.icon} ${selected.label}</div><div class="form-grid"><div class="field"><label>اسم المحل</label><input required name="shopName" /></div><div class="field"><label>اسم المالك</label><input required name="ownerName" /></div><div class="field"><label>الدولة</label><input required name="country" /></div><div class="field"><label>العملة</label><input required name="currency" placeholder="USD" /></div><div class="field"><label>رقم الهاتف</label><input required name="phone" /></div><div class="field"><label>العنوان</label><input required name="address" /></div><div class="field"><label>الرقم الضريبي</label><input name="taxNo" /></div><div class="field"><label>البريد الإلكتروني</label><input required type="email" name="email" /></div><div class="field"><label>اسم المستخدم</label><input required name="username" /></div><div class="field"><label>كلمة المرور</label><input required type="password" name="password" /></div><div class="field"><label>اسم الفرع الأول</label><input required name="branchName" /></div></div><div class="actions"><button class="btn" type="submit">إنشاء المحل والدخول</button></div></form>`;
}

function renderLoginForm() {
  return h`<form id="login-form" class="grid"><div class="field"><label>البريد الإلكتروني</label><input required type="email" name="email" /></div><div class="field"><label>كلمة المرور</label><input required type="password" name="password" /></div><div class="actions"><button class="btn" type="submit">تسجيل الدخول</button></div></form>`;
}

function renderAdminForm() {
  if (state.adminLoginMode === 'bootstrap') {
    return h`<form id="admin-bootstrap-form" class="grid"><div class="field"><label>اسم المدير</label><input required name="displayName" value="Platform Admin" /></div><div class="field"><label>البريد الإلكتروني</label><input required type="email" name="email" /></div><div class="field"><label>كلمة المرور</label><input required type="password" name="password" /></div><div class="actions"><button class="btn" type="submit">إنشاء أول مدير منصة</button></div></form>`;
  }
  return h`<form id="admin-login-form" class="grid"><div class="field"><label>البريد الإلكتروني</label><input required type="email" name="email" /></div><div class="field"><label>كلمة المرور</label><input required type="password" name="password" /></div><div class="actions"><button class="btn" type="submit">دخول لوحة الإدارة المركزية</button></div></form>`;
}

function renderWelcome() {
  const selected = ACTIVITY_CATALOG.find((a) => a.key === state.registrationActivity);
  app.innerHTML = h`<div class="hero premium-hero"><div class="hero-grid"><section class="panel panel-dark hero-aside"><div class="hero-brand"><span class="hero-kicker">${BRAND.projectNameEn}</span><h1 class="title">${BRAND.projectName}</h1><p class="subtitle">تجربة عملية لإدارة المبيعات والمشتريات والمخزون والفروع والصلاحيات، بواجهة عربية أنيقة ومباشرة.</p></div><div class="lux-grid"><div class="lux-card"><strong>مبيعات وفواتير</strong><span>POS سريع وطباعة فاتورة فورية</span></div><div class="lux-card"><strong>فروع وصلاحيات</strong><span>إدارة الوصول حسب الدور والفرع</span></div><div class="lux-card"><strong>تقارير ومخزون</strong><span>متابعة دقيقة للحركة والرصيد</span></div></div></section><section class="panel auth-panel">${noticeBlock()}<div class="login-tabs"><button class="btn ${state.authTab === 'register' ? '' : 'secondary'}" data-tab="register">تسجيل محل جديد</button><button class="btn ${state.authTab === 'login' ? '' : 'secondary'}" data-tab="login">دخول المحل</button><button class="btn ${state.authTab === 'admin' ? '' : 'secondary'}" data-tab="admin">الإدارة المركزية</button></div><div class="auth-head"><div><h2>${state.authTab === 'register' ? 'إنشاء حساب المحل' : state.authTab === 'login' ? 'الدخول إلى النظام' : 'دخول الإدارة'}</h2><p>${state.authTab === 'register' ? selected.label : state.authTab === 'login' ? 'استخدم بيانات الحساب المسجل' : 'إدارة التراخيص والعملاء'}</p></div></div>${state.authTab === 'register' ? renderRegisterForm(selected) : state.authTab === 'login' ? renderLoginForm() : renderAdminForm()}</section></div></div>`;
  bindWelcomeEvents();
}

function renderSidebar() {
  const activity = currentActivityConfig();
  const labels = { dashboard: 'لوحة التحكم', products: 'المنتجات', sales: 'المبيعات / POS', customers: 'العملاء والتحصيل', purchases: 'المشتريات', inventory: 'المخزون', reports: 'التقارير', settings: 'الإعدادات والفروع والصلاحيات', services: 'الخدمات / الصيانة' };
  return h`<aside class="sidebar"><div class="brand"><div class="brand-mark">ن</div><div><h1>${BRAND.projectName}</h1><p>${currentTenant().shopName}</p></div></div><div class="nav-label">النشاط الحالي</div><div class="badge" style="background:rgba(255,255,255,.12);color:#fff;border:none">${activity.icon} ${activity.label}</div><div class="nav-group"><div class="nav-label">القائمة</div>${activity.sidebar.map((item) => `<button class="nav-btn ${state.section===item?'active':''}" data-section="${item}"><span>${labels[item]}</span><span>‹</span></button>`).join('')}</div><div class="nav-group"><div class="nav-label">الحساب</div><button class="nav-btn" id="logout-btn"><span>تسجيل الخروج</span><span>×</span></button></div></aside>`;
}

function renderDashboard() {
  const k = computeKpis();
  const recentSales = scopedItems(state.session.sales).filter((sale) => sale.status === 'posted').slice(0, 5);
  const recentPurchases = scopedItems(state.session.purchases).filter((purchase) => purchase.status === 'posted').slice(0, 5);
  const lowStock = scopedItems(state.session.products).filter((p) => p.stockQty <= p.minStock);
  return h`<div class="grid four"><div class="card kpi"><h3>إجمالي المبيعات</h3><strong>${money(k.sales)}</strong></div><div class="card kpi"><h3>إجمالي المشتريات</h3><strong>${money(k.purchases)}</strong></div><div class="card kpi"><h3>الرصيد المخزني</h3><strong>${k.stock}</strong></div><div class="card kpi"><h3>المبالغ المعلقة</h3><strong>${money(k.due)}</strong></div></div><div class="grid two" style="margin-top:18px"><section class="card"><div class="section-head"><h3>آخر المبيعات</h3><span>${recentSales.length} عملية</span></div>${recentSales.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>الفاتورة</th><th>التاريخ</th><th>الإجمالي</th></tr></thead><tbody>${recentSales.map((s) => `<tr><td>${s.invoiceNo}</td><td>${formatDate(s.createdAt)}</td><td>${money(s.grandTotal)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا توجد بيانات.</div>'}</section><section class="card"><div class="section-head"><h3>آخر المشتريات</h3><span>${recentPurchases.length} عملية</span></div>${recentPurchases.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>الفاتورة</th><th>التاريخ</th><th>الإجمالي</th></tr></thead><tbody>${recentPurchases.map((p) => `<tr><td>${p.invoiceNo}</td><td>${formatDate(p.createdAt)}</td><td>${money(p.grandTotal)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا توجد بيانات.</div>'}</section></div><section class="card" style="margin-top:18px"><div class="section-head"><h3>تنبيهات المخزون</h3><span>${lowStock.length} صنف</span></div>${lowStock.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>الصنف</th><th>المتاح</th><th>الحد الأدنى</th></tr></thead><tbody>${lowStock.map((p) => `<tr><td>${p.name}</td><td>${p.stockQty}</td><td>${p.minStock}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا توجد تنبيهات حالياً.</div>'}</section>`;
}

function renderProducts() {
  const activity = currentActivityConfig();
  const products = scopedItems(state.session.products);
  const options = products.map((p) => `<option value="${p.id}">${p.name}</option>`).join('');
  return h`<div class="grid two"><section class="card"><div class="section-head"><h3>إضافة صنف</h3><span>${products.length}</span></div><form id="product-form" class="grid"><div class="form-grid"><div class="field"><label>اسم الصنف</label><input required name="name" /></div><div class="field"><label>كود الصنف</label><input name="code" /></div><div class="field"><label>الباركود</label><input name="barcode" /></div><div class="field"><label>تكلفة الشراء</label><input name="purchasePrice" type="number" min="0" step="0.01" /></div><div class="field"><label>سعر البيع</label><input name="salePrice" type="number" min="0" step="0.01" /></div><div class="field"><label>الكمية الافتتاحية</label><input name="stockQty" type="number" min="0" step="1" /></div><div class="field"><label>الحد الأدنى للمخزون</label><input name="minStock" type="number" min="0" step="1" /></div>${activity.specializedFields.map(([key, label]) => `<div class="field"><label>${label}</label><input name="${key}" /></div>`).join('')}</div><div class="actions"><button class="btn" type="submit">حفظ الصنف</button></div></form></section><section class="card"><div class="section-head"><h3>بيانات المنتجات</h3><span>${products.length}</span></div>${products.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>الاسم</th><th>الكود</th><th>المخزون</th><th>سعر البيع</th><th>تنبيه</th></tr></thead><tbody>${products.map((p) => `<tr><td>${p.name}</td><td>${p.code}</td><td>${p.stockQty}</td><td>${money(p.salePrice)}</td><td>${p.stockQty <= p.minStock ? 'منخفض' : 'جيد'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا توجد منتجات بعد.</div>'}<div class="grid two" style="margin-top:16px"><form id="product-update-form" class="card subcard"><div class="section-head"><h3>تحديث صنف</h3><span>تعديل الأسعار</span></div><div class="grid"><div class="field"><label>الصنف</label><select name="productId" required><option value="">اختر</option>${options}</select></div><div class="field"><label>سعر الشراء الجديد</label><input name="purchasePrice" type="number" min="0" step="0.01" /></div><div class="field"><label>سعر البيع الجديد</label><input name="salePrice" type="number" min="0" step="0.01" /></div><div class="field"><label>حد المخزون الأدنى</label><input name="minStock" type="number" min="0" step="1" /></div><div class="actions"><button class="btn secondary" type="submit">تحديث الصنف</button></div></div></form><form id="adjust-stock-form" class="card subcard"><div class="section-head"><h3>تسوية المخزون</h3><span>إضافة أو خصم</span></div><div class="grid"><div class="field"><label>الصنف</label><select name="productId" required><option value="">اختر</option>${options}</select></div><div class="field"><label>كمية التعديل</label><input name="qtyDelta" type="number" step="1" placeholder="مثال: 5 أو -2" /></div><div class="field"><label>السبب</label><input name="reason" placeholder="manual_adjustment" /></div><div class="field"><label>ملاحظة</label><input name="note" /></div><div class="actions"><button class="btn ghost" type="submit">حفظ التسوية</button></div></div></form></div></section></div>`;
}

function renderSales() {
  const branchProducts = scopedItems(state.session.products);
  const filtered = branchProducts.filter((p) => p.name.includes(state.posSearch) || p.code.includes(state.posSearch) || (p.barcode || '').includes(state.posSearch));
  const sales = scopedItems(state.session.sales);
  const customers = scopedItems(state.session.customers);
  const totals = cartTotals();
  return h`<div class="split"><section class="card"><div class="section-head"><h3>نقطة البيع</h3><span>${filtered.length}</span></div><div class="form-grid"><div class="field"><label>بحث</label><input id="pos-search" value="${state.posSearch}" placeholder="اسم أو كود أو باركود" /></div><div class="field"><label>مقاس الفاتورة</label><select id="print-size"><option value="58" ${state.invoicePrintSize==='58'?'selected':''}>58mm</option><option value="80" ${state.invoicePrintSize==='80'?'selected':''}>80mm</option><option value="A4" ${state.invoicePrintSize==='A4'?'selected':''}>A4</option></select></div></div>${filtered.length ? `<div class="table-wrap" style="margin-top:12px"><table class="table"><thead><tr><th>الصنف</th><th>المتوفر</th><th>السعر</th><th></th></tr></thead><tbody>${filtered.map((p) => `<tr><td>${p.name}</td><td>${p.stockQty}</td><td>${money(p.salePrice)}</td><td><button class="btn secondary add-cart" data-product="${p.id}">إضافة</button></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا توجد منتجات في هذا الفرع.</div>'}</section><section class="card"><div class="section-head"><h3>سلة البيع</h3><span>${state.cart.length}</span></div><form id="checkout-form">${state.cart.length ? state.cart.map((item) => `<div class="cart-item"><strong>${item.name}</strong><input type="number" min="1" value="${item.qty}" data-qty="${item.productId}" /><span>${money(item.salePrice)}</span><button type="button" class="btn ghost remove-item" data-remove="${item.productId}">حذف</button></div>`).join('') : '<div class="empty">السلة فارغة.</div>'}<div class="totals"><div class="total-row"><span>الإجمالي</span><strong>${money(totals.grandTotal)}</strong></div></div><div class="form-grid" style="margin-top:12px"><div class="field"><label>طريقة الدفع</label><select name="paymentMethod">${PAYMENT_METHODS.map((p) => `<option value="${p.value}">${p.label}</option>`).join('')}</select></div><div class="field"><label>المدفوع</label><input type="number" min="0" step="0.01" name="paid" value="${totals.grandTotal || 0}" /></div><div class="field"><label>اسم العميل</label><input name="customerName" list="customer-names" placeholder="اختياري للنقدي وإلزامي للآجل" /></div><div class="field"><label>هاتف العميل</label><input name="customerPhone" /></div><div class="field"><label>ملاحظات</label><input name="notes" /></div><div class="field"><label>مفتاح منع التكرار</label><input name="idempotencyKey" value="${uid('idem')}" /></div></div><datalist id="customer-names">${customers.map((customer) => `<option value="${customer.name}">`).join('')}</datalist><div class="actions"><button class="btn success" type="submit">إتمام البيع</button></div></form></section></div><section class="card" style="margin-top:18px"><div class="section-head"><h3>سجل المبيعات</h3><div class="actions"><span>${sales.length}</span><button type="button" class="btn ghost export-sales">تصدير CSV</button></div></div>${sales.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>الفاتورة</th><th>التاريخ</th><th>الحالة</th><th>الدفع</th><th>العميل</th><th>الإجمالي</th><th>المتبقي</th><th>إجراء</th></tr></thead><tbody>${sales.map((s) => `<tr><td>${s.invoiceNo}</td><td>${formatDate(s.createdAt)}</td><td>${s.status}</td><td>${PAYMENT_METHODS.find((m) => m.value === s.paymentMethod)?.label || s.paymentMethod}</td><td>${(state.session.customers || []).find((c) => c.id === s.customerId)?.name || '-'}</td><td>${money(s.grandTotal)}</td><td>${money(s.remaining)}</td><td>${s.status === 'posted' && can('void_invoices') ? `<div class="actions"><button type="button" class="btn ghost reverse-sale" data-id="${s.id}" data-mode="returned">مرتجع</button><button type="button" class="btn danger reverse-sale" data-id="${s.id}" data-mode="voided">إلغاء</button></div>` : '-'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا توجد عمليات بيع بعد.</div>'}</section>`;
}

function renderCustomers() {
  const customers = scopedItems(state.session.customers);
  const payments = scopedItems(state.session.customerPayments);
  const totalOutstanding = customers.reduce((sum, customer) => sum + customerOutstanding(customer.id), 0);
  return h`<div class="grid two"><section class="card"><div class="section-head"><h3>العملاء</h3><div class="actions"><span>${customers.length}</span><button type="button" class="btn ghost export-customers">تصدير CSV</button></div></div>${customers.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>الاسم</th><th>الهاتف</th><th>الرصيد المستحق</th></tr></thead><tbody>${customers.map((customer) => `<tr><td>${customer.name}</td><td>${customer.phone || '-'}</td><td>${money(customerOutstanding(customer.id))}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا توجد بيانات عملاء بعد.</div>'}<div class="stat-line" style="margin-top:12px">إجمالي الذمم: <strong>${money(totalOutstanding)}</strong></div></section><section class="card"><div class="section-head"><h3>إضافة عميل</h3><span>حساب جديد</span></div><form id="customer-form" class="grid"><div class="form-grid"><div class="field"><label>اسم العميل</label><input required name="name" /></div><div class="field"><label>الهاتف</label><input name="phone" /></div><div class="field"><label>البريد الإلكتروني</label><input type="email" name="email" /></div><div class="field"><label>العنوان</label><input name="address" /></div></div><div class="actions"><button class="btn" type="submit">حفظ العميل</button></div></form></section></div><div class="grid two" style="margin-top:18px"><section class="card"><div class="section-head"><h3>سداد دفعة عميل</h3><span>${payments.length}</span></div><form id="customer-payment-form" class="grid"><div class="form-grid"><div class="field"><label>العميل</label><select name="customerId" required><option value="">اختر</option>${customers.map((customer) => `<option value="${customer.id}">${customer.name}</option>`).join('')}</select></div><div class="field"><label>المبلغ</label><input required type="number" min="0.01" step="0.01" name="amount" /></div><div class="field"><label>طريقة الدفع</label><select name="paymentMethod">${PAYMENT_METHODS.map((p) => `<option value="${p.value}">${p.label}</option>`).join('')}</select></div><div class="field"><label>ملاحظات</label><input name="notes" /></div></div><div class="actions"><button class="btn secondary" type="submit">تسجيل الدفعة</button></div></form></section><section class="card"><div class="section-head"><h3>آخر السدادات</h3><span>${payments.length}</span></div>${payments.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>العميل</th><th>المبلغ</th><th>التاريخ</th></tr></thead><tbody>${payments.slice(0, 20).map((payment) => `<tr><td>${customers.find((customer) => customer.id === payment.customerId)?.name || '-'}</td><td>${money(payment.amount)}</td><td>${formatDate(payment.createdAt)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا توجد دفعات بعد.</div>'}</section></div>`;
}

function renderPurchases() {
  const products = scopedItems(state.session.products);
  const purchases = scopedItems(state.session.purchases);
  return h`<div class="grid two"><section class="card"><div class="section-head"><h3>فاتورة شراء</h3><span>${products.length}</span></div><form id="purchase-form" class="grid"><div class="form-grid"><div class="field"><label>اسم المورد</label><input required name="supplierName" /></div><div class="field"><label>هاتف المورد</label><input name="supplierPhone" /></div><div class="field"><label>الصنف</label><select name="productId" required><option value="">اختر</option>${products.map((p) => `<option value="${p.id}">${p.name}</option>`).join('')}</select></div><div class="field"><label>الكمية</label><input required type="number" min="1" step="1" name="qty" /></div><div class="field"><label>تكلفة الوحدة</label><input required type="number" min="0" step="0.01" name="unitCost" /></div><div class="field"><label>خصم</label><input type="number" min="0" step="0.01" name="discount" value="0" /></div><div class="field"><label>مصاريف إضافية</label><input type="number" min="0" step="0.01" name="extraExpenses" value="0" /></div><div class="field"><label>المدفوع</label><input type="number" min="0" step="0.01" name="paid" value="0" /></div></div><div class="actions"><button class="btn" type="submit">حفظ الفاتورة</button></div></form></section><section class="card"><div class="section-head"><h3>الموردون</h3><span>${state.session.suppliers.length}</span></div>${state.session.suppliers.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>الاسم</th><th>الهاتف</th></tr></thead><tbody>${state.session.suppliers.map((s) => `<tr><td>${s.name}</td><td>${s.phone || '-'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا توجد بيانات.</div>'}</section></div><section class="card" style="margin-top:18px"><div class="section-head"><h3>سجل المشتريات</h3><div class="actions"><span>${purchases.length}</span><button type="button" class="btn ghost export-purchases">تصدير CSV</button></div></div>${purchases.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>الفاتورة</th><th>التاريخ</th><th>الحالة</th><th>الإجمالي</th><th>المتبقي</th><th>إجراء</th></tr></thead><tbody>${purchases.map((p) => `<tr><td>${p.invoiceNo}</td><td>${formatDate(p.createdAt)}</td><td>${p.status}</td><td>${money(p.grandTotal)}</td><td>${money(p.remaining)}</td><td>${p.status === 'posted' && can('manage_purchases') ? `<div class="actions"><button type="button" class="btn ghost reverse-purchase" data-id="${p.id}" data-mode="returned">مرتجع</button><button type="button" class="btn danger reverse-purchase" data-id="${p.id}" data-mode="voided">إلغاء</button></div>` : '-'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا توجد مشتريات بعد.</div>'}</section>`;
}

function renderInventory() {
  const products = scopedItems(state.session.products);
  const movements = scopedItems(state.session.stockMovements);
  return h`<div class="grid two"><section class="card"><div class="section-head"><h3>الرصيد الحالي</h3><span>${products.length}</span></div>${products.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>الصنف</th><th>الكمية</th><th>الحد الأدنى</th><th>الحالة</th></tr></thead><tbody>${products.map((p) => `<tr><td>${p.name}</td><td>${p.stockQty}</td><td>${p.minStock}</td><td>${p.stockQty <= p.minStock ? 'تنبيه نقص' : 'طبيعي'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا يوجد مخزون بعد.</div>'}</section><section class="card"><div class="section-head"><h3>حركة المخزون</h3><span>${movements.length}</span></div>${movements.length ? `<div class="audit-list">${movements.slice(0,20).map((m) => { const product = state.session.products.find((p) => p.id === m.productId); return `<div class="audit-item"><strong>${product?.name || 'صنف'}</strong><div class="stat-line">${m.qtyDelta > 0 ? '+' : ''}${m.qtyDelta} — ${m.reason} — ${formatDate(m.at)}</div></div>`; }).join('')}</div>` : '<div class="empty">لا توجد حركة مخزون بعد.</div>'}</section></div>`;
}

function renderReports() {
  const r = calculateReports();
  const customers = scopedItems(state.session.customers);
  const outstanding = customers.reduce((sum, customer) => sum + customerOutstanding(customer.id), 0);
  return h`<div class="grid four"><div class="card kpi"><h3>الإيراد</h3><strong>${money(r.revenue)}</strong></div><div class="card kpi"><h3>تكلفة البضاعة المباعة</h3><strong>${money(r.cogs)}</strong></div><div class="card kpi"><h3>صافي الربح</h3><strong>${money(r.profit)}</strong></div><div class="card kpi"><h3>الذمم المدينة</h3><strong>${money(outstanding)}</strong></div></div><section class="card" style="margin-top:18px"><div class="section-head"><h3>ملخص تحليلي</h3><button type="button" class="btn ghost export-report">تصدير CSV</button></div><div class="table-wrap"><table class="table"><tbody><tr><th>المنتجات الراكدة</th><td>${r.stagnant}</td></tr><tr><th>إجمالي المبيعات</th><td>${money(computeKpis().sales)}</td></tr><tr><th>إجمالي المشتريات</th><td>${money(computeKpis().purchases)}</td></tr><tr><th>المبالغ المستحقة</th><td>${money(computeKpis().due)}</td></tr><tr><th>ذمم العملاء</th><td>${money(outstanding)}</td></tr></tbody></table></div></section>`;
}

function renderSettings() {
  const branchCards = state.session.branches.map((branch) => `<div class="audit-item branch-card"><strong>${branch.name}</strong><div class="stat-line">${branch.phone || '-'} • ${branch.address || '-'}</div></div>`).join('') || '<div class="empty">لا توجد بيانات.</div>';
  const teamRows = state.session.team.map((member) => `<tr><td>${member.displayName || member.username}</td><td>${member.roleCode}</td><td>${member.isActive ? 'نشط' : 'معطل'}</td><td>${member.branches.map((branchId) => state.session.branches.find((b) => b.id === branchId)?.name || branchId).join('، ')}</td><td>${permissionSummary(member.permissions)}</td><td>${member.id !== state.session.user.id && can('manage_users') ? `<button type="button" class="btn ${member.isActive ? 'warn' : 'secondary'} toggle-user-active" data-id="${member.id}" data-active="${member.isActive ? 'false' : 'true'}">${member.isActive ? 'تعطيل' : 'تفعيل'}</button>` : '-'}</td></tr>`).join('') || '<tr><td colspan="6">لا توجد بيانات.</td></tr>';
  const roleOptions = ['manager', 'cashier', 'accountant', 'storekeeper', 'employee'];
  return h`<div class="grid two"><section class="card"><div class="section-head"><h3>بيانات المحل</h3><span>${currentTenant().licenseStatus}</span></div><div class="table-wrap"><table class="table"><tbody><tr><th>اسم المحل</th><td>${currentTenant().shopName}</td></tr><tr><th>المالك</th><td>${currentTenant().ownerName}</td></tr><tr><th>الهاتف</th><td>${currentTenant().phone}</td></tr><tr><th>العنوان</th><td>${currentTenant().address}</td></tr><tr><th>العملة</th><td>${currentTenant().currency}</td></tr><tr><th>البريد</th><td>${state.session.user.email}</td></tr></tbody></table></div><div class="stat-line" style="margin-top:12px">الدور الحالي: <strong>${state.session.user.role}</strong> • الفرع الحالي: <strong>${activeBranchName()}</strong></div></section><section class="card"><div class="section-head"><h3>شعار رأس الفاتورة</h3><span>من الإعدادات</span></div><div style="display:grid;gap:12px"><img src="${invoiceHeaderLogo()}" alt="logo" style="max-width:220px;max-height:160px;object-fit:contain;border:1px solid #e2e8f0;border-radius:12px;padding:12px;background:#fff" /><form id="invoice-logo-form" class="grid"><div class="field"><label>شعار صاحب السستم في رأس الفاتورة</label><input type="file" name="invoiceHeaderLogo" accept="image/*" /></div><div class="actions"><button class="btn secondary" type="submit">حفظ الشعار</button></div></form><div class="stat-line">يظهر هذا الشعار في رأس الفاتورة، بينما تبقى العلامة المائية كما هي.</div></div></section></div><div class="grid two" style="margin-top:18px"><section class="card"><div class="section-head"><h3>الفروع</h3><span>${state.session.branches.length}</span></div>${branchCards}${can('manage_branches') ? `<form id="branch-form" class="grid" style="margin-top:16px"><div class="form-grid"><div class="field"><label>اسم الفرع</label><input required name="name" /></div><div class="field"><label>الهاتف</label><input name="phone" /></div><div class="field"><label>العنوان</label><input name="address" /></div></div><div class="actions"><button class="btn" type="submit">حفظ الفرع</button></div></form>` : ''}</section><section class="card"><div class="section-head"><h3>سجل العمليات</h3><span>${state.session.auditLogs.length}</span></div>${state.session.auditLogs.length ? `<div class="audit-list">${state.session.auditLogs.slice(0,12).map((a) => `<div class="audit-item"><strong>${a.action}</strong><div class="stat-line">${a.details} — ${formatDate(a.at)}</div></div>`).join('')}</div>` : '<div class="empty">لا توجد بيانات.</div>'}</section></div><div class="grid two" style="margin-top:18px"><section class="card"><div class="section-head"><h3>المستخدمون والصلاحيات</h3><span>${state.session.team.length}</span></div><div class="table-wrap"><table class="table"><thead><tr><th>المستخدم</th><th>الدور</th><th>الحالة</th><th>الفروع</th><th>الصلاحيات</th><th>الإجراء</th></tr></thead><tbody>${teamRows}</tbody></table></div>${can('manage_users') ? `<form id="staff-form" class="grid" style="margin-top:16px"><div class="form-grid"><div class="field"><label>الاسم</label><input required name="displayName" /></div><div class="field"><label>اسم المستخدم</label><input required name="username" /></div><div class="field"><label>البريد الإلكتروني</label><input required type="email" name="email" /></div><div class="field"><label>كلمة المرور</label><input required type="password" name="password" /></div><div class="field"><label>الدور</label><select name="roleCode" id="role-code-select">${roleOptions.map((role) => `<option value="${role}" ${role === 'cashier' ? 'selected' : ''}>${role}</option>`).join('')}</select></div></div><div class="field"><label>الفروع</label><div class="audit-list branch-picks">${state.session.branches.map((branch) => `<label class="audit-item"><input type="checkbox" name="branchIds" value="${branch.id}" checked /> ${branch.name}</label>`).join('')}</div></div><div class="field"><label>الصلاحيات</label><div class="audit-list permission-picks">${PERMISSIONS.map((permission) => `<label class="audit-item"><input type="checkbox" name="${permission.key}" ${ROLE_TEMPLATES.cashier[permission.key] ? 'checked' : ''} /> ${permission.label}</label>`).join('')}</div></div><div class="actions"><button class="btn" type="submit">حفظ المستخدم</button></div></form>` : ''}</section></div>`;
}

function renderServices() {
  return `<section class="card"><div class="section-head"><h3>الخدمات</h3><span>0</span></div><div class="empty">لا توجد بيانات.</div></section>`;
}

function renderApp() {
  const activity = currentActivityConfig();
  const sectionTitles = { dashboard: 'لوحة التحكم', products: 'المنتجات', sales: 'المبيعات ونقطة البيع', customers: 'العملاء والتحصيل', purchases: 'المشتريات والموردون', inventory: 'إدارة المخزون', reports: 'التقارير', settings: 'الفروع والمستخدمون والصلاحيات', services: 'الخدمات' };
  const sections = { dashboard: renderDashboard, products: renderProducts, sales: renderSales, customers: renderCustomers, purchases: renderPurchases, inventory: renderInventory, reports: renderReports, settings: renderSettings, services: renderServices };
  const branchOptions = availableBranchesForCurrentUser();
  app.innerHTML = h`<div class="app-shell">${renderSidebar()}<main class="main">${noticeBlock()}<div class="topbar"><div><h2>${sectionTitles[state.section]}</h2><p>${activity.label} • ${currentTenant().shopName}</p></div><div class="badges">${branchOptions.length > 1 ? `<select id="branch-switcher" class="branch-switcher">${branchOptions.map((branch) => `<option value="${branch.id}" ${branch.id === currentOperationalBranchId() ? 'selected' : ''}>${branch.name}</option>`).join('')}</select>` : `<span class="badge">${activeBranchName()}</span>`}<span class="badge">${state.session.user.displayName || state.session.user.username}</span><span class="badge">${state.session.license?.status || currentTenant().licenseStatus}</span></div></div>${sections[state.section]()}</main></div>`;
  bindAppEvents();
}

function renderAdmin() {
  const tenants = state.adminData.tenants || [];
  const logs = state.adminData.logs || [];
  app.innerHTML = h`<div class="hero admin-shell"><div class="topbar"><div><h2>الإدارة المركزية</h2><p>إدارة العملاء والتراخيص وحالة الحسابات.</p></div><div class="actions"><button class="btn danger" id="logout-admin-btn">تسجيل الخروج</button></div></div>${noticeBlock()}<div class="grid four"><div class="card kpi"><h3>عدد المحلات</h3><strong>${state.adminData.stats.totalTenants}</strong></div><div class="card kpi"><h3>التراخيص النشطة</h3><strong>${state.adminData.stats.activeTenants}</strong></div><div class="card kpi"><h3>الموقوفة</h3><strong>${state.adminData.stats.suspendedTenants}</strong></div><div class="card kpi"><h3>عدد الفروع</h3><strong>${state.adminData.stats.totalBranches}</strong></div></div><section class="card" style="margin-top:18px"><div class="section-head"><h3>الحسابات المسجلة</h3><span>${tenants.length}</span></div>${tenants.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>المحل</th><th>المالك</th><th>النشاط</th><th>الفروع</th><th>الحالة</th><th>الخطة</th><th>الإجراء</th></tr></thead><tbody>${tenants.map((tenant) => `<tr><td>${tenant.shopName}</td><td>${tenant.ownerName}</td><td>${ACTIVITY_CATALOG.find((a) => a.key === tenant.activityKey)?.label || tenant.activityKey}</td><td>${tenant.branchCount}</td><td>${tenant.licenseStatus}</td><td>${tenant.license?.plan_code || tenant.license?.planCode || '-'}</td><td><div class="actions"><button class="btn secondary admin-license" data-id="${tenant.id}" data-status="active">تفعيل</button><button class="btn warn admin-license" data-id="${tenant.id}" data-status="pending">انتظار</button><button class="btn danger admin-license" data-id="${tenant.id}" data-status="suspended">إيقاف</button></div></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا توجد بيانات.</div>'}</section><section class="card" style="margin-top:18px"><div class="section-head"><h3>سجل الإدارة</h3><span>${logs.length}</span></div>${logs.length ? `<div class="audit-list">${logs.slice(0,20).map((log) => `<div class="audit-item"><strong>${log.action}</strong><div class="stat-line">${JSON.stringify(log.details || {})} — ${formatDate(log.created_at)}</div></div>`).join('')}</div>` : '<div class="empty">لا توجد بيانات.</div>'}</section></div>`;
  bindAdminEvents();
}

function bindWelcomeEvents() {
  document.querySelectorAll('[data-tab]').forEach((btn) => btn.addEventListener('click', () => { state.authTab = btn.dataset.tab; render(); }));
  document.getElementById('register-form')?.addEventListener('change', (e) => { if (e.target.name === 'activityKey') { state.registrationActivity = e.target.value; render(); } });
  document.getElementById('register-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await registerTenant(Object.fromEntries(new FormData(e.currentTarget).entries())); } catch (error) { setErrorNotice(error); state.screen = 'welcome'; } finally { state.syncing = false; render(); }
  });
  document.getElementById('login-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); const form = Object.fromEntries(new FormData(e.currentTarget).entries()); await loginTenant(form.email, form.password); } catch (error) { setErrorNotice(error); state.screen = 'welcome'; } finally { state.syncing = false; render(); }
  });
  document.getElementById('admin-bootstrap-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await bootstrapAdmin(Object.fromEntries(new FormData(e.currentTarget).entries())); } catch (error) { setErrorNotice(error); state.screen = 'welcome'; } finally { state.syncing = false; render(); }
  });
  document.getElementById('admin-login-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); const form = Object.fromEntries(new FormData(e.currentTarget).entries()); await loginAdmin(form.email, form.password); } catch (error) { setErrorNotice(error); state.screen = 'welcome'; } finally { state.syncing = false; render(); }
  });
}

function bindAppEvents() {
  document.querySelectorAll('[data-section]').forEach((btn) => btn.addEventListener('click', () => { state.section = btn.dataset.section; render(); }));
  document.getElementById('logout-btn')?.addEventListener('click', async () => { await logoutAll(); render(); });
  document.getElementById('branch-switcher')?.addEventListener('change', (e) => { state.selectedBranchId = e.target.value; state.cart = []; render(); });
  document.getElementById('product-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await createProduct(Object.fromEntries(new FormData(e.currentTarget).entries())); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); }
  });
  document.getElementById('product-update-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await updateProductDetails(Object.fromEntries(new FormData(e.currentTarget).entries())); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); }
  });
  document.getElementById('adjust-stock-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await adjustStock(Object.fromEntries(new FormData(e.currentTarget).entries())); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); }
  });
  document.getElementById('customer-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await createCustomer(Object.fromEntries(new FormData(e.currentTarget).entries())); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); }
  });
  document.getElementById('customer-payment-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await receiveCustomerPayment(Object.fromEntries(new FormData(e.currentTarget).entries())); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); }
  });
  document.getElementById('purchase-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await recordPurchase(Object.fromEntries(new FormData(e.currentTarget).entries())); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); }
  });
  document.getElementById('branch-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await createBranch(Object.fromEntries(new FormData(e.currentTarget).entries())); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); }
  });
  document.getElementById('invoice-logo-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await updateInvoiceHeaderLogo(e.currentTarget); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); }
  });
  const roleSelect = document.getElementById('role-code-select');
  const syncRolePermissions = () => {
    const template = ROLE_TEMPLATES[roleSelect?.value] || ROLE_TEMPLATES.employee;
    PERMISSIONS.forEach((permission) => {
      const input = document.querySelector(`input[name="${permission.key}"]`);
      if (input) input.checked = !!template[permission.key];
    });
  };
  roleSelect?.addEventListener('change', syncRolePermissions);
  if (roleSelect) syncRolePermissions();
  document.getElementById('staff-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await createStaffUser(new FormData(e.currentTarget)); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); }
  });
  document.getElementById('pos-search')?.addEventListener('input', (e) => { state.posSearch = e.target.value; render(); });
  document.getElementById('print-size')?.addEventListener('change', (e) => { state.invoicePrintSize = e.target.value; });
  document.querySelectorAll('.add-cart').forEach((btn) => btn.addEventListener('click', () => addToCart(btn.dataset.product)));
  document.querySelectorAll('[data-qty]').forEach((input) => input.addEventListener('change', () => updateCartQty(input.dataset.qty, input.value)));
  document.querySelectorAll('.remove-item').forEach((btn) => btn.addEventListener('click', () => { state.cart = state.cart.filter((i) => i.productId !== btn.dataset.remove); render(); }));
  document.querySelectorAll('.reverse-sale').forEach((btn) => btn.addEventListener('click', async () => { try { state.syncing = true; state.screen = 'loading'; render(); await reverseSale(btn.dataset.id, btn.dataset.mode); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); } }));
  document.querySelectorAll('.reverse-purchase').forEach((btn) => btn.addEventListener('click', async () => { try { state.syncing = true; state.screen = 'loading'; render(); await reversePurchase(btn.dataset.id, btn.dataset.mode); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); } }));
  document.querySelectorAll('.toggle-user-active').forEach((btn) => btn.addEventListener('click', async () => { try { state.syncing = true; state.screen = 'loading'; render(); await toggleUserActive(btn.dataset.id, btn.dataset.active === 'true'); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); } }));
  document.querySelector('.export-sales')?.addEventListener('click', () => { const rows = scopedItems(state.session.sales).map((sale) => [sale.invoiceNo, sale.status, sale.paymentMethod, (state.session.customers || []).find((c) => c.id === sale.customerId)?.name || '', sale.grandTotal, sale.remaining, sale.createdAt]); downloadCsv('sales.csv', ['invoice_no','status','payment_method','customer','grand_total','remaining','created_at'], rows); });
  document.querySelector('.export-purchases')?.addEventListener('click', () => { const rows = scopedItems(state.session.purchases).map((purchase) => [purchase.invoiceNo, purchase.status, purchase.grandTotal, purchase.remaining, purchase.createdAt]); downloadCsv('purchases.csv', ['invoice_no','status','grand_total','remaining','created_at'], rows); });
  document.querySelector('.export-customers')?.addEventListener('click', () => { const rows = scopedItems(state.session.customers).map((customer) => [customer.name, customer.phone, customer.email, customerOutstanding(customer.id), customer.createdAt]); downloadCsv('customers.csv', ['name','phone','email','outstanding','created_at'], rows); });
  document.querySelector('.export-report')?.addEventListener('click', () => { const kpi = computeKpis(); const rep = calculateReports(); downloadCsv('report-summary.csv', ['metric','value'], [['sales', kpi.sales], ['purchases', kpi.purchases], ['due', kpi.due], ['revenue', rep.revenue], ['cogs', rep.cogs], ['profit', rep.profit]]); });
  document.getElementById('checkout-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { state.syncing = true; state.screen = 'loading'; render(); await checkoutSale(Object.fromEntries(new FormData(e.currentTarget).entries())); state.screen = 'app'; } catch (error) { setErrorNotice(error); state.screen = 'app'; } finally { state.syncing = false; render(); }
  });
}

function bindAdminEvents() {
  document.getElementById('logout-admin-btn')?.addEventListener('click', async () => { await logoutAll(); render(); });
  document.querySelectorAll('.admin-license').forEach((btn) => btn.addEventListener('click', async () => {
    try { state.syncing = true; state.screen = 'loading'; render(); await updateLicense(btn.dataset.id, btn.dataset.status); state.screen = 'admin'; } catch (error) { setErrorNotice(error); state.screen = 'admin'; } finally { state.syncing = false; render(); }
  }));
}

function render() {
  if (state.screen === 'loading') return renderLoading();
  if (state.screen === 'welcome') return renderWelcome();
  if (state.screen === 'app') return renderApp();
  if (state.screen === 'admin') return renderAdmin();
}

if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});

(async function init() {
  try {
    validateConfig();
    await initializeSession();
  } catch (error) {
    setErrorNotice(error);
    state.screen = 'welcome';
  }
  state.syncing = false;
  render();
})();
